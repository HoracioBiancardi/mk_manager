---
created: '2026-06-26T13:25:36.584644+00:00'
folder: arq
id: fluxo-de-carregamento-do-datasphere-config
modified: '2026-06-26T15:07:46.969214+00:00'
status: ''
tags:
- arq
- tecnico
- datasphere
title: Fluxo de carregamento do datasphere( config )
type: note
---
# 📊 Fluxo de Carga Datasphere V3 (Header → Itens + Triggers)

## 🎯 Conceito
- **Header (Cabeçalho)**: entidade principal (ex: documento)
- **Itens (Lines/Detalhe)**: dependem do header
- **Trigger**: definido via `cron schedule`
- **Execução**: baseada em domínios e frequência

---

# ⏱️ ORQUESTRAÇÃO COMPLETA (Triggers + Hierarquia Header/Item)

| Pipeline | Frequência | Schedule | Descrição | Tabelas Pai (Header) | Tabelas Filhas (Itens) |
|----------|-----------|----------|----------|----------------------|------------------------|
| datasphere_master_daily_h9 | Diário | `0 9 * * *` | Master data | - | EKKN, EBKN, KNA1, KNKK, MARA, MAKT, LFA1 |
| datasphere_hr_daily_h10 | Diário | `0 10 * * *` | Recursos humanos | HRP1000 | HRP1001, PA0000, PA0001, PA0002, PA0041, T500P, T529T, T530T, CSKT |
| datasphere_fi_hourly_h25 | Horário | `25 * * * *` | FI - Documentos | BKPF | BSEG |
| datasphere_fi_hourly_h45 | Horário | `45 * * * *` | FI - AR/AP | - | BSAD, BSID |
| datasphere_fi_daily_h8 | Diário | `0 8 * * *` | FI - auxiliares | - | T052U |
| datasphere_sd_hourly_h10 | Horário | `10 * * * *` | SD - Pedido | VBAK | VBAP, VBUP |
| datasphere_sd_hourly_h15 | Horário | `15 * * * *` | SD - Entrega/Faturamento | LIKP, VBRK | LIPS, VBRP, VBPA |
| datasphere_mm_hourly_h30 | Horário | `30 * * * *` | MM - Compras | EKKO | EKPO |
| datasphere_mm_daily_X | 4x ao dia | `15 */4 * * *` | Estoque | - | MARD, MCHB, MCH1 |
| datasphere_mm_daily_h7 | Diário | `0 7 * * *` | Movimentação / Fiscal | MKPF, RBKP | MSEG, RSEG |

---


# 💰 FI (Financeiro)

## 📄 Documento Contábil
**Trigger:** `datasphere_fi_hourly_h25` → a cada hora no minuto 25

```
BKPF (Header)
  └── BSEG (Itens)
```

### Execução
1. Carrega BKPF (últimos 30 dias)
2. Chunk de BELNR
3. Carrega BSEG via header

---

## 💳 Contas a Receber
**Trigger:** `datasphere_fi_hourly_h45`

```
BSID (Aberto)
BSAD (Compensado)
```

---

# 🧾 SD (Vendas)

## 🛒 Pedido de Venda  
**Trigger:** `datasphere_sd_hourly_h10`

```
VBAK (Header)
  ├── VBAP (Itens)
  ├── VBUP (Status)
  └── VBPA (Parceiros)
```

---

## 🚚 Entrega + Faturamento  
**Trigger:** `datasphere_sd_hourly_h15`

```
LIKP (Header)
  └── LIPS (Itens)

VBRK (Header)
  └── VBRP (Itens)
      └── VBPA (Parceiros)
```

---

## 🔗 Fluxo de Documentos

```
VBFA
```

### Executado junto com SD (h15)

---

# 📦 MM (Compras / Estoque)

## 🛒 Pedido de Compra  
**Trigger:** `datasphere_mm_hourly_h30`

```
EKKO (Header)
  └── EKPO (Itens)
```

### Execução
1. Filtra por `AEDAT`
2. Carrega header
3. Chunk de pedidos
4. Carrega itens

---

## 📦 Movimentação de Material  
**Trigger:** `datasphere_mm_daily_h7`

```
MKPF (Header)
  └── MSEG (Itens)
```

---

## 🧾 Fatura Fornecedor  
**Trigger:** `datasphere_mm_daily_h7`

```
RBKP (Header)
  └── RSEG (Itens)
```

---

## 🏬 Estoque  
**Trigger:** `datasphere_mm_daily_X` (4x por dia)

```
MARD
MCHB
MCH1
```

---

# 👨‍💼 HR (Recursos Humanos)

## 🧑 Colaborador  
**Trigger:** `datasphere_hr_daily_h10`

```
PA0000
PA0001
PA0002
PA0041
```

---

## 🧱 Estrutura Organizacional  

```
HRP1000
  └── HRP1001
```

---

# 📐 ORDEM GLOBAL DE EXECUÇÃO

## 🟢 Pipeline macro

```
1. master_daily_h9
2. mm_daily_h7
3. fi_daily_h8
4. hr_daily_h10
```

## 🔵 Pipelines incrementais (loop horário)

```
10 → SD Pedido (VBAK)
15 → SD Entrega/Fatura
25 → FI Documentos (BKPF/BSEG)
30 → MM Compras (EKKO/EKPO)
45 → FI AR/AP
```

---

# ⚙️ PADRÃO DE TRIGGER

## 📌 Exemplo real (FI)

```yaml
schedule: "25 * * * *"
range_column: "BUDAT"
range_start: "{LAST_30_DAYS}"
range_end: "{TODAY}"
```

---

# 🚀 RESUMO EXECUTIVO

## 🔄 Ciclo completo:

```
[Master]
   ↓
[Headers]
   ↓
[Itens via chunk]
   ↓
[Relacionamentos (VBFA)]
   ↓
[Snapshots]
   ↓
[Gold Layer]
```

---

# 📌 BOAS PRÁTICAS

✅ Sempre carregar header antes  
✅ Usar chunk para tabelas grandes (BSEG, MSEG, VBAP)  
✅ Separar triggers por domínio  
✅ Evitar overlap de carga (cada domínio em slot diferente do cron)  

---

# ✅ RESULTADO

- Baixo acoplamento entre pipelines
- Alta paralelização
- Controle de latência por domínio
- Preparado para orquestração via Airflow (Datasets ✅)

