---
created: '2026-06-24T17:54:38.916044+00:00'
folder: arq
id: kafka-debezium-sink-guia-completo
modified: '2026-06-26T15:10:33.380839+00:00'
status: ''
tags:
- tecnico
- arq
title: Kafka + Debezium + Sink (Guia Completo)
type: note
---
# Kafka + Debezium + Sink (Guia Completo)

## Remove as imagens
```bash
docker rm -f kafka zookeeper kafka-connect
```

## Cria rede docker
```bash
docker network create kafka-net
```

## Subir Zookeeper

```bash
docker run -d \
--name zookeeper \
--network kafka-net \
-e ZOOKEEPER_CLIENT_PORT=2181 \
-e ZOOKEEPER_TICK_TIME=2000 \
confluentinc/cp-zookeeper:7.4.0
```

## Subir Kafka

```bash
docker run -d \
--name kafka \
--network kafka-net \
-p 9092:9092 \
-e KAFKA_BROKER_ID=1 \
-e KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 \
-e KAFKA_LISTENERS=PLAINTEXT://0.0.0.0:29092,PLAINTEXT_HOST://0.0.0.0:9092 \
-e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://kafka:29092,PLAINTEXT_HOST://172.16.108.238:9092 \
-e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT \
-e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT \
-e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 \
confluentinc/cp-kafka:7.4.0
```

## 👉 Esse foi o ponto crítico que resolveu comunicação entre containers

## Subir Kafka Connect (Debezium)

```bash
docker run -d \
--name kafka-connect \
--network kafka-net \
-p 8083:8083 \
-e BOOTSTRAP_SERVERS=kafka:29092 \
-e GROUP_ID=1 \
-e CONFIG_STORAGE_TOPIC=my_connect_configs \
-e OFFSET_STORAGE_TOPIC=my_connect_offsets \
-e STATUS_STORAGE_TOPIC=my_connect_statuses \
-e CONFIG_STORAGE_REPLICATION_FACTOR=1 \
-e OFFSET_STORAGE_REPLICATION_FACTOR=1 \
-e STATUS_STORAGE_REPLICATION_FACTOR=1 \
-e KEY_CONVERTER=org.apache.kafka.connect.json.JsonConverter \
-e VALUE_CONVERTER=org.apache.kafka.connect.json.JsonConverter \
debezium/connect:2.4
```

## Validar stack
```bash
docker ps
```


Esperado:
zookeeper ✅
kafka ✅
kafka-connect ✅





## Habilitar CDC no SQL Server
```sql
USE GOLD;
EXEC sys.sp_cdc_enable_db;

USE GOLD;
EXEC sys.sp_cdc_enable_table
@source_schema = 'dbo',
@source_name   = 'SuaTabela',
@role_name     = NULL;
@supports_net_changes = 1;

--Verificar as tabelas que estão no cdc
USE GOLD;
SELECT * FROM cdc.change_tables;

--Verificar se esta habilitado o cdc no banco
SELECT name, is_cdc_enabled
FROM sys.databases
WHERE name = 'GOLD';


--Habilitar o usuario
ALTER ROLE cdc_reader ADD MEMBER datawarehouse;


UPDATE GOLD.suprimentos.teste
SET
    descricao = 'Registro atualizado para testar CDC',
    data_atualizacao = GETDATE()
WHERE nome = 'Teste CDC';


INSERT INTO GOLD.suprimentos.teste (
    nome,
    descricao,
    ativo,
    data_criacao
)
VALUES (
    'Teste CDC',
    'Primeiro registro para CDC',
    1,
    GETDATE()
);


# Código para criar o connector

```python
import requests
import json
import time
from confluent_kafka import Consumer
from confluent_kafka.admin import AdminClient, NewTopic

# =========================================
# CONFIG
# =========================================
KAFKA_CONNECT_URL = "http://172.16.108.238:8083/connectors"
KAFKA_BOOTSTRAP = "172.16.108.238:9092"

SOURCE_NAME = "sqlserver-cdc"
SINK_NAME = "postgres-sink"

SCHEMA_TOPIC = "schema-changes.sqlserver"
DATA_TOPIC = "sqlserver-cdc.GOLD.suprimentos.teste"


# =========================================
# CONNECTOR HTTP UTILS
# =========================================
def delete_connector(name: str):
    r = requests.delete(f"{KAFKA_CONNECT_URL}/{name}")
    print(f"DELETE {name}: {r.status_code}")


def create_connector(payload: dict):
    r = requests.post(
        KAFKA_CONNECT_URL,
        headers={"Content-Type": "application/json"},
        data=json.dumps(payload),
    )
    print(f"CREATE {payload['name']}: {r.status_code}")
    print(r.text)


def get_status(name: str):
    r = requests.get(f"{KAFKA_CONNECT_URL}/{name}/status")
    print(f"STATUS {name}: {r.status_code}")
    print(r.text)


# =========================================
# KAFKA ADMIN
# =========================================
def create_schema_history_topic():
    print("\n📌 Criando topic schema history...")

    admin = AdminClient({"bootstrap.servers": KAFKA_BOOTSTRAP})

    topic = NewTopic(
        SCHEMA_TOPIC,
        num_partitions=1,
        replication_factor=1,
        config={"cleanup.policy": "compact"},
    )

    fs = admin.create_topics([topic])

    for topic, f in fs.items():
        try:
            f.result()
            print(f"✅ Topic criado: {topic}")
        except Exception as e:
            print(f"⚠️ Topic já existe ou erro: {e}")


def list_topics():
    print("\n📌 Listando tópicos Kafka...")

    admin = AdminClient({"bootstrap.servers": KAFKA_BOOTSTRAP})
    metadata = admin.list_topics(timeout=10)

    for t in metadata.topics:
        print(f" - {t}")


# =========================================
# KAFKA CONSUMER
# =========================================
def check_topic_messages(topic, timeout=10):
    print(f"\n🔎 Verificando mensagens em: {topic}")

    conf = {
        "bootstrap.servers": KAFKA_BOOTSTRAP,
        "group.id": "debug-consumer",
        "auto.offset.reset": "earliest",
    }

    consumer = Consumer(conf)
    consumer.subscribe([topic])

    start = time.time()
    found = False

    try:
        while time.time() - start < timeout:
            msg = consumer.poll(1.0)

            if msg is None:
                continue

            if msg.error():
                print(f"Erro: {msg.error()}")
                continue

            print("\n✅ EVENTO CDC RECEBIDO:\n")

            try:
                payload = json.loads(msg.value().decode("utf-8"))
                print(json.dumps(payload, indent=2))
            except:
                print(msg.value().decode("utf-8"))

            found = True
            break

        if not found:
            print("\n⚠️ Nenhuma mensagem encontrada!")

    finally:
        consumer.close()


# =========================================
# CONNECTOR CONFIG
# =========================================
sqlserver_source = {
    "name": "sqlserver-cdc",
    "config": {
        "connector.class": "io.debezium.connector.sqlserver.SqlServerConnector",
        "tasks.max": "1",
        "database.hostname": "172.16.108.172",
        "database.port": "1433",
        "database.user": "datawarehouse",
        "database.password": "N&&Q){m@=4aa",
        "database.names": "GOLD",
        "topic.prefix": "sqlserver-cdc",
        "table.include.list": "suprimentos.teste",
        "schema.history.internal.kafka.bootstrap.servers": "kafka:9092",
        "schema.history.internal.kafka.topic": SCHEMA_TOPIC,
        "snapshot.mode": "initial",
    },
}

postgres_sink = {
    "name": "postgres-sink",
    "config": {
        "connector.class": "io.debezium.connector.jdbc.JdbcSinkConnector",
        "tasks.max": "1",
        "topics.regex": "sqlserver-cdc\\..*",
        "connection.url": "jdbc:postgresql://172.16.108.237:5432/DB",
        "connection.username": "postgres",
        "connection.password": "postgres",
        "insert.mode": "upsert",
        "primary.key.mode": "record_key",
        "primary.key.fields": "id_teste",
        "delete.enabled": "true",
        "schema.evolution": "basic",
    },
}


# =========================================
# PIPELINE ORCHESTRATION
# =========================================
def run_pipeline_debug():
    print("\n🔥 1. Criando schema history topic...")
    create_schema_history_topic()

    time.sleep(2)

    print("\n🔥 2. Deletando connectors...")
    delete_connector(SOURCE_NAME)
    delete_connector(SINK_NAME)

    time.sleep(3)

    print("\n🚀 3. Criando SOURCE...")
    create_connector(sqlserver_source)

    time.sleep(5)

    print("\n🚀 4. Criando SINK...")
    create_connector(postgres_sink)

    time.sleep(5)

    print("\n✅ 5. Status dos connectors...")
    get_status(SOURCE_NAME)
    get_status(SINK_NAME)

    print("\n📌 6. Listando tópicos...")
    list_topics()

    print("\n🚀 7. Verificando dados CDC...")
    check_topic_messages(DATA_TOPIC)


# =========================================
# MAIN
# =========================================
if __name__ == "__main__":
    run_pipeline_debug()

```
