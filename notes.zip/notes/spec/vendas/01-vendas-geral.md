---
created: '2026-06-29T18:36:46.952197+00:00'
folder: spec/vendas
id: 01-vendas-geral
modified: '2026-06-29T20:24:52.924174+00:00'
status: ''
tags: []
title: 01 - Vendas Geral
type: note
---
# Documentação Arquitetural: Arquitetura e Ingestão de Dados SAP ECC

Esta documentação técnica consolida a arquitetura de ponta a ponta para a ingestão, tratamento e modelagem dimensional dos dados provenientes do SAP ECC, englobando Clientes, Materiais, Centros, Estoque, Vendas, Faturamento e Pendências sob o padrão de arquitetura Medalhão.

---

## 1. Fluxo de Dados Completo e Linhagem Geral (Mapeamento de Todas as Tabelas)

O diagrama de blocos abaixo mapeia detalhadamente todas as tabelas operacionais e satélites do SAP ECC ingeridas na camada Bronze, padronizadas na Silver e consolidadas no modelo dimensional *Star Schema* da Gold.

```
========================================================================================
[CAMADA BRONZE]                  [CAMADA SILVER]                  [CAMADA GOLD]
 Dados Brutos (ERP)               Staging / Tipagem                Modelo Dimensional
========================================================================================

1. ESTEIRA DE CADASTROS (DIMENSÕES MESTRE ESTENDIDAS)
 ┌───────────────┐               ┌────────────────┐
 │   sap_kna1    │ ────────────> │  stg_sap_kna1  │ ───┐
 ├───────────────┤               ├────────────────┤    │
 │   sap_knvv    │ ────────────> │  stg_sap_knvv  │ ───┤
 ├───────────────┤               ├────────────────┤    │          ┌───────────────┐
 │sap_tvkot/t151t│ ────────────> │stg_tvkot/t151t │ ───┼────────> │  dim_cliente  │
 ├───────────────┤               ├────────────────┤    │          └───────────────┘
 │sap_tvzbt/tpvot│ ────────────> │stg_tvzbt/tpvot │ ───┤ 
 ├───────────────┤               ├────────────────┤    │
 │sap_tsvkt/tspat│ ────────────> │stg_tsvkt/tspat │ ───┘
 └───────────────┘               └────────────────┘
 
 ┌───────────────┐               ┌────────────────┐
 │   sap_mara    │ ────────────> │  stg_sap_mara  │ ───┐
 ├───────────────┤               ├────────────────┤    │          ┌───────────────┐
 │   sap_makt    │ ────────────> │  stg_sap_makt  │ ───┼────────> │ dim_material  │
 ├───────────────┤               ├────────────────┤    │          └───────────────┘
 │sap_t023t/t134t│ ────────────> │stg_t023t/t134t │ ───┘
 └───────────────┘               └────────────────┘
 
 ┌───────────────┐               ┌────────────────┐
 │   sap_t001w   │ ────────────> │  stg_sap_t001w │ ───┐          ┌───────────────┐
 ├───────────────┤               ├────────────────┤    ├────────> │  dim_centro   │
 │   sap_tvkwz   │ ────────────> │  stg_sap_tvkwz │ ───┘          └───────────────┘
 └───────────────┘               └────────────────┘

2. ESTEIRA DE POSIÇÃO DE INVENTÁRIO (ESTOQUE VALORADO)
 ┌───────────────┐               ┌────────────────┐
 │   sap_mard    │ ────────────> │  stg_sap_mard  │ ───┐          ┌───────────────┐
 ├───────────────┤               ├────────────────┤    ├────────> │fct_estoque_pos│
 │   sap_mbew    │ ────────────> │  stg_sap_mbew  │ ───┘          └───────────────┘
 └───────────────┘               └────────────────┘

3. ESTEIRA DE CAPTAÇÃO DE PEDIDOS (DEMANDA DE VENDAS)
 ┌───────────────┐               ┌────────────────┐
 │   sap_vbak    │ ────────────> │  stg_sap_vbak  │ ───┐          ┌───────────────┐
 ├───────────────┤               ├────────────────┤    ├────────> │fct_vendas_itns│
 │   sap_vbap    │ ────────────> │  stg_sap_vbap  │ ───┘          └───────────────┘
 └───────────────┘               └────────────────┘

4. ESTEIRA DE RECEITA REALIZADA (FATURAMENTO HISTÓRICO)
 ┌───────────────┐               ┌────────────────┐
 │   sap_vbrk    │ ────────────> │  stg_sap_vbrk  │ ───┐          ┌───────────────┐
 ├───────────────┤               ├────────────────┤    ├────────> │fct_faturam_itn│
 │   sap_vbrp    │ ────────────> │  stg_sap_vbrp  │ ───┘          └───────────────┘
 └───────────────┘               └────────────────┘

5. ESTEIRA RESIDUAL DE PENDÊNCIAS (BACKLOG COMERCIAL)
                                 ┌────────────────┐
                                 │  stg_sap_vbap  │ ───┐
                                 └────────────────┘    │
                                 ┌────────────────┐    │          ┌───────────────┐
                                 │  stg_sap_vbep  │ ───┼────────> │fct_vendas_pend│
                                 └────────────────┘    │          └───────────────┘
                                 ┌────────────────┐    │
                                 │  stg_sap_vbrp  │ ───┘
                                 └────────────────┘
```

---

## 2. Matriz Consolidada de Tabelas e Entidades do Pipeline

A tabela abaixo sumariza todas as tabelas do ecossistema SAP que foram ingeridas e como elas ficaram estruturadas após o processamento na camada **Gold**.

| Nome do Objeto Gold | Tipo de Entidade | Tabelas SAP de Origem | Chave Primária / Grão Analítico na Gold | Objetivo Comercial de Negócio |
| :--- | :---: | :--- | :--- | :--- |
| **`dim_cliente`** | Dimensão | `KNA1`, `KNVV`, `TVKOT`, `T151T`, `TVZBT`, `TPVOT`, `TSVKT`, `TSPAT` | `sk_cliente` (`MANDT`+`KUNNR`+`VKORG`+`VTWEG`+`SPART`) | Visão 360° do parceiro atrelado às regras, canais, prazos e legendas de sua Área de Vendas. |
| **`dim_material`** | Dimensão | `MARA`, `MAKT`, `T023T`, `T134T` | `sk_material` (`MANDT`+`MATNR`) | Índice mestre de produtos, categorizados por famílias, tipos de estoque e metadados logísticos. |
| **`dim_centro`** | Dimensão | `T001W`, `TVKWZ`, `TVKOT` | `sk_centro` (`MANDT`+`WERKS`+`VKORG`) | Cadastro de plantas físicas, CDs ou fábricas vinculadas às suas filiais comerciais autorizadas. |
| **`fct_estoque_posicao`** | Fato | `MARD`, `MBEW` | `MANDT` + `MATNR` + `WERKS` + `LGORT` | Snapshot instantâneo do volume físico e custo do inventário parado em armazém. |
| **`fct_vendas_itens`** | Fato | `VBAK`, `VBAP` | `MANDT` + `VBELN` + `POSNR` | Histórico acumulado da captação de novos pedidos e curva de demanda do mercado. |
| **`fct_faturamento_itens`** | Fato | `VBRK`, `VBRP` | `MANDT` + `VBELN` + `POSNR` | Registro oficial de receita contábil real, impostos e margem gerada por saídas de Notas Fiscais. |
| **`fct_vendas_pendencias`** | Fato | `VBAP`, `VBEP`, `VBRP` | `MANDT` + `VBELN` + `POSNR` + `ETENR` | Balanço residual dinâmico (Backlog) indicando contratos ativos que a empresa ainda deve entregar. |

---

## 3. Resumo Executivo das 3 Regras de Ouro Aplicadas

Para que esta esteira opere em nível corporativo de alta senioridade, o pipeline aplica três regras fundamentais de engenharia na transição da camada Silver para a Gold:

1. **Campos de Controle Temporais e Incrementais (`ERDAT` / `AEDAT`):** A extração das fatos transacionais e cadastros volumosos deve monitorar as datas de modificação (`AEDAT`) e inclusão (`ERDAT`) para rodar em modo incremental via CDC, poupando a infraestrutura do ERP SAP.
2. **Eliminação de Registros de Descarte Contábil (`ABRUV` / `FKSTO`):** O SAP preserva históricos de auditoria intactos. Itens de pedidos recusados (`ABRUV` preenchido) e Notas Fiscais canceladas (`FKSTO = 'X'`) são filtrados e expurgados nativamente nas queries SQL para evitar que os dashboards de BI exibam receita ou demanda infladas falsamente.
3. **Padrão Transacional de Relacionamento (Uso de `AUBEL` / `VGBEL`):** Para ligar o faturamento de volta ao pedido original sem derrubar a performance do banco com a gigante tabela `VBFA`, a arquitetura utiliza os campos nativos de herança contidos na própria `VBRP` (`AUBEL` para número de pedido e `AUPOS` para item), otimizando o custo computacional do Data Warehouse.