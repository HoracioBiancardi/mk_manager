---
created: '2026-06-27T18:55:07.512884+00:00'
folder: spec/vendas
id: spec-dim-material-sap
modified: '2026-06-29T20:29:37.769713+00:00'
status: ''
tags:
- spec
- sap
- vendas
- material
title: Spec - dim_material SAP
type: note
---
# Documentação Técnico-Comercial: Dimensão Consolidada de Materiais (dim_material)

Esta documentação detalha a especificação de dados e a arquitetura da **Dimensão Material (`dim_material`)**, projetada para centralizar o cadastro técnico de produtos, codificações comerciais e estruturas de famílias de mercadorias do SAP ECC em uma visão analítica padronizada para Business Intelligence.

---

## 1. Fluxo de Integração e Cruzamento (Arquitetura em Blocos)

As informações de materiais no SAP ECC seguem uma arquitetura central de engenharia: as propriedades físicas globais e imutáveis do produto residem em um nível mestre centralizado, enquanto as descrições comerciais e os agrupamentos de mercado se acoplam por meio de tabelas satélites de parametrização e tradução.

```
===================================================================================
[CAMADA SILVER: BASE CORE]       [CAMADA SILVER: TRADUÇÕES]       [CAMADA GOLD]
 Dados Mestres / Estrutura        Tabelas Satélites (Textos)       Dimensão Final
===================================================================================

 ┌──────────────────────┐    ┌─────────────────────────┐
 │   silver.stg_mara    │ ──>│ silver.stg_makt  (Nome) │ ───┐
 └──────────────────────┘    └─────────────────────────┘    │
                             ┌─────────────────────────┐    ├─> ┌───────────────┐
                             │ silver.stg_t023t (Famíl)│ ───┤   │ gold.dim_     │
                             └─────────────────────────┘    │   │   material    │
                             ┌─────────────────────────┐    │   └───────────────┘
                             │ silver.stg_t134t (Tipo) │ ───┘
                             └─────────────────────────┘
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `dim_material` atua como a entidade dimensional de portfólio, fornecendo contexto e capacidade de agregação para todas as métricas de faturamento realizado, posições de inventário e itens retidos em carteira. 

Diferente de tabelas dinâmicas ou transacionais, a `dim_material` preserva a granularidade estritamente ao nível de **Material por Mandante (`MANDT` + `MATNR`)**. O isolamento completo de saldos instantâneos ou localizações físicas de estoque (como os dados da `MARD` ou `MARC`) garante que a dimensão funcione como um índice mestre limpo, blindando o modelo Star Schema contra a duplicação cartesiana de linhas durante os cruzamentos com os documentos de vendas e movimentações físicas.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária (SAP) | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **MARA** | Mestre de materiais: dados gerais | Dado Mestre | `MANDT`, `MATNR` | Centraliza os atributos físicos estruturais, classificações de inventário e chaves de agrupamento global do item. |
| **MAKT** | Mestre de materiais: descrições | Parametrização | `MANDT`, `MATNR`, `SPRAS` | Armazena os nomes e nomenclaturas comerciais dos produtos de acordo com o idioma logado. |
| **T023T** | Textos do grupo de mercadorias | Parametrização | `MANDT`, `MATKL`, `SPRAS` | Converte os códigos técnicos de agrupamento do SAP em nomes amigáveis por extenso para as famílias de produtos. |
| **T134T** | Textos do tipo de material | Parametrização | `MANDT`, `MTART`, `SPRAS` | Converte os códigos de categorias do SAP em descrições por extenso (ex: Produto Acabado). |

---

## 4. Principais Campos Cadastrais

Estes campos fornecem os atributos nominais e as descrições oficiais que identificam os produtos de forma clara nas telas e relatórios do usuário:

| Campo SAP | Nome Técnico | Tabela Origem | Significado no Negócio | Tipo de Conteúdo |
| :--- | :--- | :---: | :--- | :--- |
| **`MANDT`** | Mandante | MARA / MAKT | Identificador do ambiente lógico/isolado corporativo do SAP. | Alfanumérico (Ex: `400`) |
| **`MATNR`** | Material | MARA / MAKT | Código identificador exclusivo e universal do produto no SAP. | Alfanumérico (Tratado sem zeros à esquerda na Gold) |
| **`MAKTX`** | Descrição | MAKT | Nome comercial do item (exatamente o texto impresso na Nota Fiscal). | VARCHAR(100) |
| **`MATKL`** | Grupo Mercadorias | MARA / T023T | Código interno de classificação da família de produtos do portfólio. | Código de Categoria (ex: `ELET`) |
| **`WGBEZ`** | Descr. Grupo Merc. | T023T | Nome por extenso da família de produtos para uso em gráficos e eixos. | VARCHAR(50) (ex: "Materiais Elétricos") |
| **`MEINS`** | Unid. Medida Base | MARA | Unidade de medida padrão adotada internamente para controle de movimentações. | Sigla (ex: `PC`, `KG`, `M`) |

---

## 5. Campos de Controle de Negócio

Estes campos atuam como balizadores estratégicos para regras de filtragem de inventário comercial e cálculos de capacidade volumétrica/carregamento logístico:

| Campo SAP | Nome Técnico | Tabela Origem | Função Comercial / Regra de Controle | Impacto no Fluxo |
| :---: | :---: | :---: | :--- | :--- |
| **`MTART`** | Tipo de Material | MARA / T134T | Classifica o estágio de industrialização e venda do produto. | Permite filtrar apenas vendas reais (`FERT`) |
| **`MTBEZ`** | Descr. Tipo Material| T134T | Nome por extenso do tipo de material (Ex: Produto Acabado). | Legenda descritiva clara para os agrupamentos de BI |
| **`BRGEW`** | Peso Bruto | MARA | Peso total da unidade do produto, incluindo embalagem primária. | Base de cálculo logística para cubagem de carga |
| **`NTGEW`** | Peso Líquido | MARA | Peso líquido real do material desconsiderando proteções e pallets. | Utilizado para estatísticas de volume de vendas |
| **`GEWEI`** | Unidade de Peso | MARA | Unidade de medida padrão vinculada aos pesos bruto e líquido. | Garante a integridade da métrica (`KG`, `TO`) |

---

## 6. Query SQL de Extração e Construção (`dim_material`)

```sql
-- ====================================================================================
-- PROCESSO: EXTRAÇÃO E MONTAGEM DA DIMENSÃO GOLD (dim_material)
-- TECNOLOGIA: SQL Server
-- REGRAS: Remoção de padding (zeros à esquerda), tratamento de nulos e trava de SPRAS.
-- ====================================================================================

SELECT 
    -- Geração da Surrogate Key (SK) para o modelo Star Schema
    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(MARA.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(MARA.MATNR)), '')
        )
    ), 2) AS [sk_material],

    -- Chaves de Ambiente e Naturais de Negócio
    MARA.MANDT   AS [Mandante],
    CASE 
        WHEN ISNUMERIC(MARA.MATNR) = 1 
        THEN LTRIM(RTRIM(CONVERT(VARCHAR(18), CONVERT(BIGINT, MARA.MATNR))))
        ELSE LTRIM(RTRIM(MARA.MATNR))
    END AS [Codigo_Produto],
    
    -- Atributos Descritivos e Nominais
    UPPER(LTRIM(RTRIM(MAKT.MAKTX)))   AS [Descricao_Produto],
    
    -- Parâmetros Comerciais de Controle e Agrupamento
    LTRIM(RTRIM(MARA.MTART))          AS [Tipo_Material],             
    UPPER(LTRIM(RTRIM(ISNULL(T134T.MTBEZ, 'NAO CADASTRADO')))) AS [Descricao_Tipo_Material],
    LTRIM(RTRIM(MARA.MATKL))          AS [Codigo_Grupo_Mercadorias],  
    UPPER(LTRIM(RTRIM(ISNULL(T023T.WGBEZ, 'NAO CADASTRADO')))) AS [Nome_Familia_Produto],      
    LTRIM(RTRIM(MARA.MEINS))          AS [Unidade_Medida_Base],
    
    -- Atributos Logísticos de Peso (Garantindo conversão numérica segura)
    ISNULL(MARA.BRGEW, 0)             AS [Peso_Bruto],
    ISNULL(MARA.NTGEW, 0)             AS [Peso_Liquido],
    LTRIM(RTRIM(MARA.GEWEI))          AS [Unidade_Peso],
    
    -- Metadados de Auditoria do Pipeline
    GETDATE() AS [Data_Processamento_DW]

FROM silver.stg_sap_mara AS MARA
INNER JOIN silver.stg_sap_makt AS MAKT  
    ON MARA.MATNR = MAKT.MATNR 
    AND MARA.MANDT = MAKT.MANDT 
    AND MAKT.SPRAS = 'P' -- Restrição explícita de Idioma (Português)
LEFT JOIN silver.stg_sap_t023t AS T023T 
    ON MARA.MATKL = T023T.MATKL 
    AND MARA.MANDT = T023T.MANDT 
    AND T023T.SPRAS = 'P' -- Restrição explícita de Idioma (Português)
LEFT JOIN silver.stg_sap_t134t AS T134T
    ON MARA.MTART = T134T.MTART
    AND MARA.MANDT = T134T.MANDT
    AND T134T.SPRAS = 'P' -- Restrição explícita de Idioma (Português)
```

---

## 7. Resumo e Observações Finais

* **Blindagem contra Inflação de Dados:** O filtro explícito `MAKT.SPRAS = 'P'` (Português) é mandatório no `INNER JOIN`. Caso seja omitido ou mapeado incorretamente nas tabelas satélites (`T023T`, `T134T`), o SQL Server multiplicará as linhas da dimensão para cada idioma ativo no sistema, corrompendo as agregações das tabelas fatos.
* **Isolamento de Estoque Físico:** Conforme o alinhamento arquitetural, o estoque real e dinâmico (tabela `MARD`) ou visões estendidas por centro (tabela `MARC`) não devem compor esta dimensão. O estoque possui volatilidade transacional diária, enquanto esta tabela atua estritamente como um cadastro mestre estável de produtos.
* **A Chave Surrogate Baseada em HASH:** Ao utilizar o Hash SHA2_256 combinando `MANDT` + `MATNR` para criar a `sk_material`, garantimos uma chave string fixa de alta performance para indexação no banco de dados, facilitando a portabilidade do Star Schema independentemente de estarmos utilizando SQL Server puro, Databricks ou Synapse.