---
created: '2026-06-27T18:49:40.268845+00:00'
folder: spec/vendas
id: spec-dim-clientes-sap
modified: '2026-06-29T20:29:51.992981+00:00'
status: ''
tags:
- spec
- sap
- vendas
- clientes
title: Spec - dim_clientes SAP
type: note
---
# Documentação Técnica: Dimensão Consolidada de Clientes (dim_cliente) - Versão Estendida

Esta documentação descreve a arquitetura e a especificação de dados avançada da **Dimensão Cliente (`dim_cliente`)**, projetada para unificar o cadastro geral, os canais de vendas e todas as legendas/traduções de negócio do SAP ECC em uma visão analítica completa e limpa.

---

## 1. Fluxo de Tabelas da Dimensão

Para que o usuário final não precise decifrar códigos do SAP, a `dim_cliente` realiza o cruzamento de dados mestre (`KNA1` e `KNVV`) com as respectivas tabelas satélites de tradução de parametrização do sistema.

```
=====================================================================================
[CAMADA SILVER: BASE CORE]       [CAMADA SILVER: TRADUÇÕES]       [CAMADA GOLD]
 Dados Mestres / Estrutura        Tabelas Satélites (Textos)       Dimensão Final
=====================================================================================

 ┌──────────────────────┐
 │   silver.stg_kna1    │ ───┐
 └──────────────────────┘    │
                             ▼ (INNER JOIN)
 ┌──────────────────────┐    ┌─────────────────────────┐
 │   silver.stg_knvv    │ ──>│ silver.stg_tvkot (OrgV) │ ───┐
 └──────────────────────┘    └─────────────────────────┘    │
                             ┌─────────────────────────┐    │
                             │ silver.stg_tsvkt (Canal)│ ───┤
                             └─────────────────────────┘    │
                             ┌─────────────────────────┐    │
                             │ silver.stg_tspat (Setor)│ ───┤
                             └─────────────────────────┘    │   ┌──────────────────┐
                             ┌─────────────────────────┐    ├─> │ gold.dim_cliente │
                             │ silver.stg_t151t (Grupo)│ ───┤   └──────────────────┘
                             └─────────────────────────┘    │ 
                             ┌─────────────────────────┐    │
                             │ silver.stg_tvzbt (Pagto)│ ───┤
                             └─────────────────────────┘    │
                             ┌─────────────────────────┐    │
                             │ silver.stg_tpvot (Inco) │ ───┘
                             └─────────────────────────┘
```
---

## 2. Matriz Estendida de Tabelas Utilizadas

| Tabela SAP | Descrição SAP | Chave Primária Real (SAP) | Função no Pipeline |
| :---: | :--- | :--- | :--- |
| **KNA1** | Mestre de clientes: dados gerais | `MANDT`, `KUNNR` | Cadastro legal e geográfico do cliente. |
| **KNVV** | Mestre clientes: dados de vendas | `MANDT`, `KUNNR`, `VKORG`, `VTWEG`, `SPART` | Estrutura e regras comerciais do cliente. |
| **TVKOT** | Organizações de vendas: textos | `MANDT`, `SPRAS`, `VKORG` | Traduz o código da filial/organização de vendas. |
| **T151T** | Grupos de clientes: textos | `MANDT`, `SPRAS`, `KDGRP` | Traduz a categoria de mercado do cliente. |
| **TVZBT** | Condições de pagamento: textos | `MANDT`, `SPRAS`, `ZTERM` | Traduz os prazos financeiros em formato de texto. |
| **TPVOT** | Incoterms: textos | `MANDT`, `SPRAS`, `INCO1` | Traduz as regras de responsabilidade de frete. |
| **TSVKT** | Canais de distribuição: textos | `MANDT`, `SPRAS`, `VTWEG` | Traduz os canais de escoamento (Ex: Varejo, Atacado). |
| **TSPAT** | Setores de atividade: textos | `MANDT`, `SPRAS`, `SPART` | Traduz a linha de portfólio (Ex: Químicos, Alimentos). |

---

## 3. Campos Cadastrais e Descritivos de Negócio (Gold)

A tabela final unifica códigos técnicos e suas respectivas descrições para facilitar a criação de filtros em relatórios:

| Campo Físico Gold | Tipo SQL | Origem SAP | Significado / Regra de Negócio |
| :--- | :---: | :---: | :--- |
| **`sk_cliente`** | VARCHAR(64) | HASH | Surrogate Key (Chave única de relacionamento Star Schema). |
| **`Codigo_Cliente`** | VARCHAR(10) | KNA1/KNVV | Código natural do cliente no ERP (sem zeros à esquerda). |
| **`Nome_Cliente`** | VARCHAR(100) | KNA1 | Razão Social / Nome principal da empresa. |
| **`CNPJ_CPF`** | VARCHAR(14) | KNA1 | Identificação Fiscal legal. |
| **`Descricao_Org_Vendas`** | VARCHAR(50) | TVKOT | Nome por extenso da filial faturadora. |
| **`Descricao_Canal_Distribuicao`**| VARCHAR(30) | TSVKT | Nome do canal (Atacado, Varejo, Direto). |
| **`Descricao_Setor_Atividade`** | VARCHAR(30) | TSPAT | Nome da linha de negócio/produto. |
| **`Nome_Grupo_Clientes`** | VARCHAR(50) | T151T | Categoria de relevância (Ex: Key Account). |
| **`Descricao_Condicao_Pagamento`**| VARCHAR(50) | TVZBT | Descrição clara do prazo de pagamento (Ex: 30/60 dias). |
| **`Descricao_Incoterms`** | VARCHAR(50) | TPVOT | Legenda do frete padrão contratual (Ex: Frete CIF pago). |

---

## 4. Query SQL Server de Alta Performance (`dim_cliente` Completa)

```sql
-- ====================================================================================
-- PROCESSO: CARGA DA DIMENSÃO GOLD COMPLETA (dim_cliente)
-- TECNOLOGIA: SQL Server
-- REGRAS: Denormalização de tabelas de texto, trava de idioma SPRAS e Mandante.
-- ====================================================================================

SELECT 
    -- Geração da Surrogate Key (SK) via HASH para Star Schema performático
    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(KNVV.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(KNVV.KUNNR)), ''), '|',
            ISNULL(LTRIM(RTRIM(KNVV.VKORG)), ''), '|',
            ISNULL(LTRIM(RTRIM(KNVV.VTWEG)), ''), '|',
            ISNULL(LTRIM(RTRIM(KNVV.SPART)), '')
        )
    ), 2) AS [sk_cliente],

    -- Chaves de Ambiente e Naturais
    KNVV.MANDT   AS [Mandante],
    CASE 
        WHEN ISNUMERIC(KNA1.KUNNR) = 1 
        THEN LTRIM(RTRIM(CONVERT(VARCHAR(10), CONVERT(BIGINT, KNA1.KUNNR))))
        ELSE LTRIM(RTRIM(KNA1.KUNNR))
    END AS [Codigo_Cliente],
    LTRIM(RTRIM(KNVV.VKORG))   AS [Org_Vendas],
    LTRIM(RTRIM(KNVV.VTWEG))   AS [Canal_Distribuicao],
    LTRIM(RTRIM(KNVV.SPART))   AS [Setor_Atividade],
    
    -- Atributos Cadastrais, Fiscais e Geográficos
    UPPER(LTRIM(RTRIM(KNA1.NAME1)))   AS [Nome_Cliente],
    LTRIM(RTRIM(KNA1.STCD1))          AS [CNPJ_CPF],             
    LTRIM(RTRIM(KNA1.STCD2))          AS [Inscricao_Estadual],   
    UPPER(LTRIM(RTRIM(KNA1.ORT01)))   AS [Cidade],
    UPPER(LTRIM(RTRIM(KNA1.REGIO)))   AS [Estado_UF],
    
    -- Tradução e Legendagem de Códigos de Controle Comerciais (Filtros de BI)
    UPPER(LTRIM(RTRIM(ISNULL(TVKOT.VTEXT, 'NAO CADASTRADO')))) AS [Descricao_Org_Vendas],  
    UPPER(LTRIM(RTRIM(ISNULL(TSVKT.VTEXT, 'NAO CADASTRADO')))) AS [Descricao_Canal_Distribuicao],  
    UPPER(LTRIM(RTRIM(ISNULL(TSPAT.VTEXT, 'NAO CADASTRADO')))) AS [Descricao_Setor_Atividade],  
    UPPER(LTRIM(RTRIM(ISNULL(T151T.KTEXT, 'NAO CADASTRADO')))) AS [Nome_Grupo_Clientes],
    UPPER(LTRIM(RTRIM(ISNULL(TVZBT.VTEXT, 'NAO CADASTRADO')))) AS [Descricao_Condicao_Pagamento],
    UPPER(LTRIM(RTRIM(ISNULL(TPVOT.BEZEI, 'NAO CADASTRADO')))) AS [Descricao_Incoterms],
    
    -- Metadados de Auditoria
    GETDATE() AS [Data_Processamento_DW]

FROM silver.stg_sap_kna1 AS KNA1
INNER JOIN silver.stg_sap_knvv AS KNVV  
    ON KNA1.KUNNR = KNVV.KUNNR
    AND KNA1.MANDT = KNVV.MANDT

-- Bloco de Tradução de Textos Paramétricos (Garantindo trava MANDT e SPRAS = 'P')
LEFT JOIN silver.stg_sap_tvkot AS TVKOT  
    ON KNVV.VKORG = TVKOT.VKORG AND KNVV.MANDT = TVKOT.MANDT AND TVKOT.SPRAS = 'P'
LEFT JOIN silver.stg_sap_tsvkt AS TSVKT  
    ON KNVV.VTWEG = TSVKT.VTWEG AND KNVV.MANDT = TSVKT.MANDT AND TSVKT.SPRAS = 'P'
LEFT JOIN silver.stg_sap_tspat AS TSPAT  
    ON KNVV.SPART = TSPAT.SPART AND KNVV.MANDT = TSPAT.MANDT AND TSPAT.SPRAS = 'P'
LEFT JOIN silver.stg_sap_t151t AS T151T  
    ON KNVV.KDGRP = T151T.KDGRP AND KNVV.MANDT = T151T.MANDT AND T151T.SPRAS = 'P'
LEFT JOIN silver.stg_sap_tvzbt AS TVZBT  
    ON KNVV.ZTERM = TVZBT.ZTERM AND KNVV.MANDT = TVZBT.MANDT AND TVZBT.SPRAS = 'P'
LEFT JOIN silver.stg_sap_tpvot AS TPVOT  
    ON KNVV.INCO1 = TPVOT.INCO1 AND KNVV.MANDT = TPVOT.MANDT AND TPVOT.SPRAS = 'P'
```

---

## 5. Resumo e Regra de Ouro de Performance
* **A importância da Denormalização:** Ao trazer os textos das condições de pagamento e canais para a mesma tabela de clientes, o Power BI faz apenas **um único join** para renderizar os filtros do dashboard, em vez de fazer seis joins em tabelas separadas. Isso garante que seus relatórios fiquem extremamente rápidos, mesmo manipulando milhões de linhas transacionais.