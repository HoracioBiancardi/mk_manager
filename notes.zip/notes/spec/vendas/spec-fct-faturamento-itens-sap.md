---
created: '2026-06-29T18:13:11.074544+00:00'
folder: spec/vendas
id: spec-fct-faturamento-itens-sap
modified: '2026-06-29T20:29:16.040857+00:00'
status: ''
tags:
- spec
- sap
- vendas
- faturamento
title: Spec - fct_faturamento_itens SAP
type: note
---
# Documentação Técnico-Comercial: Fato de Itens de Faturamento (fct_faturamento_itens)

Esta documentação detalha a especificação de dados e a arquitetura da **Tabela Fato de Faturamento (`fct_faturamento_itens`)**, projetada para consolidar os eventos de emissão de Notas Fiscais e Faturas comerciais do SAP ECC, permitindo análises de receita líquida, volume faturado e margem por cliente, produto e filial.

---

## 1. Fluxo de Integração e Cruzamento (Arquitetura em Blocos)

A visão de faturamento no SAP ECC é extraída a partir do par clássico do módulo SD: **VBRK** (Cabeçalho da Fatura) e **VBRP** (Itens da Fatura). O vínculo com o pedido de vendas original é feito de forma direta através dos campos de herança de fluxo contidos no próprio item faturado (`AUBEL` e `AUPOS`), dispensando a leitura da pesada tabela de fluxo documental (`VBFA`).

```
===================================================================================
[CAMADA SILVER: BASE CORE]       [CAMADA SILVER: HERANÇA]         [CAMADA GOLD]
 Dados de Itens Faturados         Dados de Cabeçalho (Faturas)     Fato Final
===================================================================================

 ┌──────────────────────┐
 │   silver.stg_vbrp    │ ───┐
 └──────────────────────┘    │
                             ▼ (INNER JOIN via VBELN e MANDT)
                             ┌─────────────────────────┐        ┌───────────────┐
                             │     silver.stg_vbrk     │ ─────> │   gold.fct_   │
                             └─────────────────────────┘        │faturamento_itm│
                                  │                             └───────────────┘
                                  ▼ (Metadados de Fluxo de Origem)
                             ┌─────────────────────────┐
                             │  [Herança de Vendas]    │
                             │  Ponteiro: AUBEL/AUPOS  │
                             └─────────────────────────┘
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `fct_faturamento_itens` funciona como uma foto de fluxo acumulado (*Transactional Fact Table*). Cada linha representa um item faturado (geralmente equivalente a uma linha de Nota Fiscal emitida para o cliente).

A granularidade deste modelo está definida ao nível de **Mandante, Documento de Faturamento e Item do Documento (`VBRP-MANDT` + `VBRP-VBELN` + `VBRP-POSNR`)**. Este nível de detalhe é obrigatório para garantir que impostos, custos de mercadoria e receitas líquidas sejam somados de forma exata, sem distorcer as margens de rentabilidade de SKUs específicos em análises multidimensionais.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária (SAP) | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **VBRK** | Documento de faturamento: dados de cabeçalho | Transacional | `MANDT`, `VBELN` | Contém os dados gerais da fatura como data do faturamento, condições de pagamento financeiro e status do documento. |
| **VBRP** | Documento de faturamento: dados de item | Transacional | `MANDT`, `VBELN`, `POSNR` | Armazena os valores monetários, volumes faturados, chaves de produtos, filiais de origem e os ponteiros para os pedidos de venda. |

---

## 4. Principais Campos e Chaves de Relacionamento

Estes campos atuam como as chaves de ligação (*Foreign Keys*) para conectar a Fato de Faturamento às dimensões e permitir o cruzamento com a esteira de pedidos:

| Campo SAP | Nome Técnico | Tabela Origem | Papel na Modelagem | Destino do Relacionamento (Star Schema) |
| :--- | :--- | :---: | :--- | :--- |
| **`sk_material`** | Hash Key Material | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_material.sk_material` |
| **`sk_cliente`** | Hash Key Cliente | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_cliente.sk_cliente` (Usando o Join composto por área de vendas) |
| **`sk_centro`** | Hash Key Centro | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_centro.sk_centro` |
| **`MANDT`** | Mandante | VBRP | Controle de Ambiente | Filtro de ambiente corporativo |
| **`VBELN`** | Doc. Faturamento | VBRP / VBRK | Chave Natural Comercial | Número da Fatura / Nota Fiscal |
| **`POSNR`** | Item Faturamento | VBRP | Chave Natural Comercial | Linha de numeração do item faturado |
| **`AUBEL`** | Documento de Origem| VBRP | Chave de Rastreabilidade | **Crucial.** Número do Pedido de Vendas que gerou essa fatura |
| **`AUPOS`** | Item de Origem | VBRP | Chave de Rastreabilidade | Número do item exato do Pedido de Vendas (`VBAP-POSNR`) |

---

## 5. Campos de Métricas e Filtros de Controle

Campos quantitativos e financeiros determinantes para o cálculo de faturamento bruto, líquido e volumes de escoamento:

| Campo SAP | Nome Técnico | Tabela Origem | Tipo | Função no Relatório / Regra de Negócio |
| :---: | :---: | :---: | :---: | :--- |
| **`FKDAT`** | Data Faturamento | VBRK | DATE (DATS) | **Filtro Temporal.** Data oficial em que a receita é reconhecida contabilmente. |
| **`FKIMG`** | Qtd. faturada real | VBRP | DECIMAL(15,3) | **Métrica.** Volume físico real de produtos que saíram do CD faturados. |
| **`NETWR`** | Valor líquido | VBRP / VBRK | DECIMAL(15,2) | **Métrica.** Valor financeiro líquido do item (faturamento antes de impostos/comissões dependendo da pricing). |
| **`WAVWR`** | Valor do custo | VBRP | DECIMAL(15,2) | **Métrica (Custo VGV).** Custo contábil da mercadoria vendida (COGS). Permite o cálculo da Margem Bruta. |
| **`FKSTO`** | Fatura estornada | VBRK | CHAR(1) | **Filtro de Controle.** Se estiver preenchido com 'X', significa que a Nota Fiscal foi cancelada/estornada. |

---

## 6. Query SQL de Extração e Consolidação (`fct_faturamento_itens`)

```sql
-- ====================================================================================
-- PROCESSO: EXTRAÇÃO E MATERIALIZAÇÃO DA FATO GOLD (fct_faturamento_itens)
-- TECNOLOGIA: SQL Server
-- REGRAS: Exclusão de estornos (FKSTO), herança de Pedidos via AUBEL e Surrogate Keys.
-- ====================================================================================

SELECT
    -- Geração de Surrogate Keys para acoplamento dimensional no Star Schema
    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(VBRP.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBRP.MATNR)), ''), '|'
        )
    ), 2) AS [sk_material],

    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(VBRK.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBRK.KUNRG)), ''), '|', -- Pagador / Cliente da Fatura
            ISNULL(LTRIM(RTRIM(VBRK.VKORG)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBRK.VTWEG)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBRK.SPART)), '')
        )
    ), 2) AS [sk_cliente],

    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(VBRP.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBRP.WERKS)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBRK.VKORG)), '')
        )
    ), 2) AS [sk_centro],

    -- Metadados e Chaves Naturais Comics (Sem padding)
    VBRP.MANDT   AS [Mandante],
    LTRIM(RTRIM(VBRP.VBELN))   AS [Numero_Faturamento],
    VBRP.POSNR                 AS [Item_Faturamento],
    
    -- Rastreabilidade da Esteira Completa (Link nativo com Vendas)
    LTRIM(RTRIM(VBRP.AUBEL))   AS [Numero_Pedido_Origem],
    VBRP.AUPOS                 AS [Item_Pedido_Origem],
    
    -- Atributos Temporais Contábeis
    CONVERT(DATE, VBRK.FKDAT)  AS [Data_Faturamento],
    
    -- Atributos de Estrutura Organização Comercial
    LTRIM(RTRIM(VBRK.VKORG))   AS [Codigo_Org_Vendas],
    LTRIM(RTRIM(VBRK.VTWEG))   AS [Codigo_Canal_Distribuicao],
    
    -- Métricas Quantitativas e Monetárias
    ISNULL(VBRP.FKIMG, 0)      AS [Qtd_Faturada],
    ISNULL(VBRP.NETWR, 0)      AS [Valor_Liquido_Faturamento],
    ISNULL(VBRP.WAVWR, 0)      AS [Valor_Custo_Mercadoria_VGV],
    
    -- Métrica Calculada Dinâmica: Margem Comercial Bruta em Moeda
    (ISNULL(VBRP.NETWR, 0) - ISNULL(VBRP.WAVWR, 0)) AS [Valor_Margem_Contribuicao_Bruta],
    
    -- Metadados do Pipeline
    GETDATE() AS [Data_Processamento_DW]

FROM silver.stg_sap_vbrp AS VBRP
INNER JOIN silver.stg_sap_vbrk AS VBRK 
    ON VBRP.VBELN = VBRK.VBELN 
    AND VBRP.MANDT = VBRK.MANDT
WHERE 
    ISNULL(VBRK.FKSTO, '') = '' -- Regra de Ouro: Ignora Faturas Estornadas/Canceladas no SAP
```

---

## 7. Resumo Executivo e Dicas de Ouro (Engenharia SAP)

* **O Filtro Salvador de Receita (`FKSTO`):** No SAP ECC, quando uma Nota Fiscal é cancelada, o sistema não deleta a linha. Ele gera uma nova fatura de estorno e marca o campo `FKSTO = 'X'` no documento original. Se você esquecer essa cláusula `WHERE`, seu dashboard vai duplicar o faturamento de vendas canceladas, inflando falsamente a receita da empresa.
* **Margem Real Automatizada (`WAVWR`):** O campo `WAVWR` traz o custo calculado do produto no momento exato em que ele saiu do estoque para o cliente. Cruzar `NETWR - WAVWR` direto na query Gold entrega para o negócio o indicador de lucro bruto sem a necessidade de criar medidas DAX pesadas no Power BI.
* **Ligação Direta Vendas $\rightarrow$ Faturamento:** Graças ao mapeamento dos campos `AUBEL` e `AUPOS` na `VBRP`, você pode cruzar os dados desta tabela fato diretamente com a tabela `fct_vendas_itens` (usando o número do pedido e item). Isso permite criar relatórios de eficácia comercial como o *Fill Rate* (Quanto do que foi pedido realmente virou Nota Fiscal).