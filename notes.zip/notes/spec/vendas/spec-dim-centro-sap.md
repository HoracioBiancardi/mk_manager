---
created: '2026-06-29T17:32:09.417943+00:00'
folder: spec/vendas
id: spec-dim-centro-sap
modified: '2026-06-29T20:30:03.287085+00:00'
status: ''
tags:
- spec
- sap
- vendas
- centro
title: Spec - dim_centro SAP
type: note
---
# Documentação Técnico-Comercial: Dimensão Consolidada de Centros (dim_centro)

Esta documentação detalha a especificação de dados e a arquitetura da **Dimensão Centro Logístico (`dim_centro`)**, projetada para centralizar a estrutura de plantas fabris, Centros de Distribuição (CDs) e suas amarrações com as Organizações de Vendas do SAP ECC em uma visão analítica para Business Intelligence.

---

## 1. Fluxo de Integração e Cruzamento (Arquitetura em Blocos)

A estrutura de centros no SAP ECC define a base da cadeia de suprimentos física. Para conectar um centro à estrutura comercial de faturamento sem gerar multiplicações indevidas, o pipeline realiza o cruzamento de dados mestre logísticos com a tabela de parametrização de governança comercial.

```
========================================================================================
[CAMADA SILVER: BASE CORE]       [CAMADA SILVER: TRADUÇÕES]       [CAMADA GOLD]
 Dados Mestres / Estrutura        Tabelas Satélites (Textos)       Dimensão Final
========================================================================================

 ┌──────────────────────┐
 │  silver.stg_t001w    │ ───┐
 └──────────────────────┘    │
                             ▼ (INNER JOIN)
 ┌──────────────────────┐    ┌─────────────────────────┐        ┌─────────────────┐
 │  silver.stg_tvkwz    │ ──>│ silver.stg_tvkot (OrgV) │ ─────> │ gold.dim_centro │
 └──────────────────────┘    └─────────────────────────┘        └─────────────────┘
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `dim_centro` é uma entidade fundamental para rastrear a origem física do escoamento de mercadorias, balanceamento de inventário e atribuição de metas por filial. 

Como um mesmo Centro Logístico físico (`WERKS`) pode expedir ou transferir mercadorias em nome de diferentes unidades de negócio ou empresas do grupo, a dimensão é modelada na granularidade de **Centro por Organização de Vendas (`WERKS` + `VKORG`)**. Isso garante o perfeito acoplamento com as tabelas Fato de Vendas e Faturamento, mapeando com precisão a planta emissora e a filial faturadora envolvidas na operação comercial.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária (SAP) | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **T001W** | Centros / Filiais | Dado Mestre | `MANDT`, `WERKS` | Centraliza os dados geográficos, fiscais e de identificação primária da planta/fábrica/CD. |
| **TVKWZ** | Unidades comerciais: centros por org.vendas | Atribuição / Parâmetro | `MANDT`, `VKORG`, `WERKS` | Tabela de customizing que faz o vínculo oficial de governança entre a estrutura logística e comercial. |
| **TVKOT** | Organizações de vendas: textos | Parametrização | `MANDT`, `SPRAS`, `VKORG` | Traduz os códigos numéricos das Organizações de Vendas em descrições textuais amigáveis. |

---

## 4. Principais Campos Cadastrais

Atributos nominais e geográficos que identificam e localizam as unidades físicas da empresa:

| Campo SAP | Nome Técnico | Tabela Origem | Significado no Negócio | Tipo de Conteúdo |
| :--- | :--- | :---: | :--- | :--- |
| **`MANDT`** | Mandante | T001W / TVKWZ | Identificador do ambiente lógico isolado do sistema SAP. | Alfanumérico (Ex: `400`) |
| **`WERKS`** | Centro | T001W | Código identificador exclusivo de 4 dígitos da planta/CD no SAP. | Alfanumérico |
| **`NAME1`** | Nome | T001W | Nome descritivo ou Razão Social daquela unidade física. | VARCHAR(100) |
| **`ORT01`** | Cidade | T001W | Município onde o Centro Logístico está construído. | VARCHAR(50) |
| **`REGIO`** | Região | T001W | Estado / Unidade Federativa da localização do centro. | VARCHAR(3) (Ex: `SP`, `RJ`) |
| **`LAND1`** | País | T001W | Chave internacional do país de localização da planta. | VARCHAR(3) (Ex: `BR`) |
| **`KUNNR`** | Cliente | T001W | Código do próprio Centro quando ele atua como cliente interno. | VARCHAR(10) (Usado para STO/Transferências) |

---

## 5. Campos de Controle de Negócio

Campos de amarração de governança que ditam as regras comerciais e fiscais da unidade de negócio:

| Campo SAP | Nome Técnico | Tabela Origem | Função Comercial / Regra de Controle | Impacto no Fluxo |
| :---: | :---: | :---: | :--- | :--- |
| **`VKORG`** | Org. Vendas | TVKWZ / TVKOT | Código da Organização de Vendas vinculada ao Centro. | Define qual filial responde pelo faturamento do item |
| **`VTEXT`** | Descrição Org. Vendas | TVKOT | Descrição textual da unidade de vendas responsável. | Legenda amigável para agrupamentos executivos |

---

## 6. Query SQL de Extração (`dim_centro`)

```sql
-- ====================================================================================
-- PROCESSO: EXTRAÇÃO E MONTAGEM DA DIMENSÃO GOLD (dim_centro)
-- TECNOLOGIA: SQL Server
-- REGRAS: Uso da tabela de ligação oficial TVKWZ, trava de SPRAS e Mandante.
-- ====================================================================================

SELECT 
    -- Geração da Surrogate Key (SK) para o modelo Star Schema
    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(T001W.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(T001W.WERKS)), ''), '|',
            ISNULL(LTRIM(RTRIM(TVKWZ.VKORG)), '')
        )
    ), 2) AS [sk_centro],

    -- Chaves de Ambiente e Naturais de Negócio
    T001W.MANDT   AS [Mandante],
    LTRIM(RTRIM(T001W.WERKS))   AS [Codigo_Centro],
    LTRIM(RTRIM(TVKWZ.VKORG))   AS [Org_Vendas_Responsavel],
    
    -- Atributos Descritivos do Centro
    UPPER(LTRIM(RTRIM(T001W.NAME1)))   AS [Nome_Centro],
    LTRIM(RTRIM(T001W.KUNNR))          AS [Cliente_SAP_Centro],
    
    -- Dados de Localização Física
    UPPER(LTRIM(RTRIM(T001W.ORT01)))   AS [Cidade_Centro],
    UPPER(LTRIM(RTRIM(T001W.REGIO)))   AS [Estado_Centro],
    UPPER(LTRIM(RTRIM(T001W.LAND1)))   AS [Pais_Centro],
    
    -- Legendagem Comercial (Tradução)
    UPPER(LTRIM(RTRIM(ISNULL(TVKOT.VTEXT, 'NAO ATRIBUIDO')))) AS [Descricao_Org_Vendas],
    
    -- Metadados de Auditoria do Pipeline
    GETDATE() AS [Data_Processamento_DW]

FROM silver.stg_sap_t001w AS T001W
INNER JOIN silver.stg_sap_tvkwz AS TVKWZ 
    ON T001W.WERKS = TVKWZ.WERKS 
    AND T001W.MANDT = TVKWZ.MANDT
LEFT JOIN silver.stg_sap_tvkot AS TVKOT 
    ON TVKWZ.VKORG = TVKOT.VKORG 
    AND TVKWZ.MANDT = TVKOT.MANDT 
    AND TVKOT.SPRAS = 'P' -- Restrição de idioma em Português
WHERE 
    T001W.WERKS IS NOT NULL
```

---

## 7. Resumo e Observações Finais

* **Correção Arquitetural Estratégica:** Substituir a amarração via `KNVV` pela tabela de customizing `TVKWZ` remove a necessidade de realizar agrupamentos complexos e `DISTINCT` em tabelas mestres de clientes volumosas. A `TVKWZ` reflete exatamente a parametrização viva do ERP SAP.
* **O Mito do Cliente do Centro (`KUNNR`):** Lembre-se que o campo `T001W.KUNNR` mapeia o Centro simulando um cliente interno. Ele é vital na camada Gold se o seu relatório de Logística precisar analisar o *Backlog* de ordens de transferência (Pedidos de compra do tipo "UB"). Mantenha-o mapeado, mas sem usá-lo para junção com faturamento padrão.
* **Granularidade do Join:** Como a chave de grão desta tabela é composta por `Codigo_Centro` + `Org_Vendas_Responsavel`, certifique-se de herdar estes dois campos na criação de índices nas tabelas fato para evitar multiplicações nas métricas analíticas.