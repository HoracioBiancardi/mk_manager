---
created: '2026-06-29T18:20:25.951847+00:00'
folder: spec/vendas
id: spec-fct-vendas-itens-sap
modified: '2026-06-29T20:28:49.393524+00:00'
status: ''
tags:
- spec
- sap
- vendas
title: Spec - fct_vendas_itens SAP
type: note
---
# Documentação Técnico-Comercial: Fato de Itens de Vendas (fct_vendas_itens)

Esta documentação detalha a especificação de dados e a arquitetura da **Tabela Fato de Itens de Vendas (`fct_vendas_itens`)**, projetada para registrar a entrada de ordens e pedidos de venda no SAP ECC, servindo como a base de análise de demanda comercial, eficiência de conversão e volumetria de contratos.

---

## 1. Fluxo de Integração e Cruzamento (Arquitetura em Blocos)

A visão de entrada de pedidos no SAP ECC é extraída a partir do par nativo do módulo SD: **VBAK** (Dados de Cabeçalho do Documento de Vendas) e **VBAP** (Dados de Item do Documento de Vendas), unindo-se por meio do número do documento (`VBELN`).

```
===================================================================================
[CAMADA SILVER: BASE CORE]       [CAMADA SILVER: CABEÇALHO]       [CAMADA GOLD]
 Dados de Itens do Pedido         Dados Gerais do Pedido           Fato Final
===================================================================================

 ┌──────────────────────┐
 │   silver.stg_vbap    │ ───┐
 └──────────────────────┘    │
                             ▼ (INNER JOIN via VBELN e MANDT)
                             ┌─────────────────────────┐        ┌───────────────┐
                             │     silver.stg_vbak     │ ─────> │   gold.fct_   │
                             └─────────────────────────┘        │ vendas_itens  │
                                                                └───────────────┘
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `fct_vendas_itens` funciona como uma fato transacional de fluxo histórico acumulado. Cada registro nesta tabela representa uma linha física de um pedido de venda colocado por um cliente. 

A granularidade do modelo está fixada ao nível de **Mandante, Número do Documento de Vendas e Número do Item (`VBAP-MANDT` + `VBAP-VBELN` + `VBAP-POSNR`)**. Manter o grão no item é vital, pois um único pedido de cabeçalho pode conter múltiplos SKUs distintos, destinados a centros logísticos ou datas de remessa diferentes.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária (SAP) | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **VBAK** | Documento de vendas: dados de cabeçalho | Transacional | `MANDT`, `VBELN` | Fornece os atributos gerais do pedido: tipo de ordem, data de criação, canal de distribuição e o código do cliente emissor da ordem. |
| **VBAP** | Documento de vendas: dados de item | Transacional | `MANDT`, `VBELN`, `POSNR` | Fornece os atributos específicos do item: SKU (Material), Centro expedidor, quantidades pedidas, pesos e valores financeiros líquidos. |

---

## 4. Principais Campos e Chaves de Relacionamento

Chaves de ligação (*Foreign Keys*) estruturadas para a conexão imediata com o ecossistema dimensional Star Schema na Gold:

| Campo SAP | Nome Técnico | Tabela Origem | Papel na Modelagem | Destino do Relacionamento (Star Schema) |
| :--- | :--- | :---: | :--- | :--- |
| **`sk_material`** | Hash Key Material | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_material.sk_material` |
| **`sk_cliente`** | Hash Key Cliente | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_cliente.sk_cliente` (Área de Vendas) |
| **`sk_centro`** | Hash Key Centro | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_centro.sk_centro` |
| **`MANDT`** | Mandante | VBAP | Controle de Ambiente | Filtro de isolamento de tenant |
| **`VBELN`** | Documento Vendas | VBAP / VBAK | Chave Natural Comercial | Código identificador do pedido/contrato |
| **`POSNR`** | Item Ordem Vendas | VBAP | Chave Natural Comercial | Sequencial da linha do produto no pedido |

---

## 5. Campos de Métricas e Filtros de Controle

Atributos analíticos e quantitativos que determinam as metas e volumes de captação de vendas:

| Campo SAP | Nome Técnico | Tabela Origem | Tipo | Função no Relatório / Regra de Negócio |
| :---: | :---: | :---: | :---: | :--- |
| **`ERDAT`** | Data de Criação | VBAK | DATE (DATS) | **Filtro Temporal.** Data em que a ordem foi registrada no SAP pelo time comercial. |
| **`AUART`** | Tipo de Documento | VBAK | CHAR(4) | **Filtro de Processo.** Identifica se é Venda Normal (`TA`/`OR`), Ordem de Bonificação (`RE`), Consignação, etc. |
| **`KWMENG`** | Qtd. da ordem | VBAP | DECIMAL(15,3) | **Métrica.** Volume físico original solicitado pelo cliente. |
| **`NETWR`** | Valor líquido | VBAP | DECIMAL(15,2) | **Métrica.** Valor financeiro líquido do item do pedido de venda antes do faturamento. |
| **`ABRUV`** | Status de Eliminação| VBAP | CHAR(1) | **Filtro de Controle.** Identifica se o item foi cancelado ou recusado comercialmente. |

---

## 6. Query SQL de Extração e Consolidação (`fct_vendas_itens`)

```sql
-- ====================================================================================
-- PROCESSO: EXTRAÇÃO E MATERIALIZAÇÃO DA FATO GOLD (fct_vendas_itens)
-- TECNOLOGIA: SQL Server
-- REGRAS: Geração de Surrogate Keys, herança da Área de Vendas e eliminação de recusas.
-- ====================================================================================

SELECT
    -- Geração de Surrogate Keys para acoplamento com o modelo de dimensões Gold
    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(VBAP.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBAP.MATNR)), '')
        )
    ), 2) AS [sk_material],

    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(VBAK.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBAK.KUNNR)), ''), '|', -- Cliente Emissor da Ordem
            ISNULL(LTRIM(RTRIM(VBAK.VKORG)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBAK.VTWEG)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBAK.SPART)), '')
        )
    ), 2) AS [sk_cliente],

    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(VBAP.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBAP.WERKS)), ''), '|',
            ISNULL(LTRIM(RTRIM(VBAK.VKORG)), '')
        )
    ), 2) AS [sk_centro],

    -- Metadados e Chaves Naturais Comerciais
    VBAP.MANDT   AS [Mandante],
    LTRIM(RTRIM(VBAP.VBELN))   AS [Numero_Pedido],
    VBAP.POSNR                 AS [Item_Pedido],
    
    -- Atributos Temporais de Entrada de Ordem
    CONVERT(DATE, VBAK.ERDAT)  AS [Data_Inclusao_Pedido],
    
    -- Atributos de Classificação de Regras do ERP
    LTRIM(RTRIM(VBAK.AUART))   AS [Tipo_Ordem_Venda],
    LTRIM(RTRIM(VBAK.VKORG))   AS [Codigo_Org_Vendas],
    LTRIM(RTRIM(VBAK.VTWEG))   AS [Codigo_Canal_Distribuicao],
    
    -- Métricas Quantitativas e Financeiras
    ISNULL(VBAP.KWMENG, 0)     AS [Qtd_Pedida_Original],
    ISNULL(VBAP.NETWR, 0)      AS [Valor_Liquido_Pedido],
    
    -- Metadados do Pipeline
    GETDATE() AS [Data_Processamento_DW]

FROM silver.stg_sap_vbap AS VBAP
INNER JOIN silver.stg_sap_vbak AS VBAK 
    ON VBAP.VBELN = VBAK.VBELN 
    AND VBAP.MANDT = VBAK.MANDT
WHERE 
    ISNULL(VBAP.ABRUV, '') = '' -- Regra de Ouro: Exclui linhas que foram explicitamente canceladas ou recusadas no ERP
```

---

## 7. Resumo Executivo e Dicas de Ouro (Engenharia SAP)

* **O Filtro de Recusa de Item (`ABRUV` / `ABGRU`):** Se um cliente desiste de um item do pedido, o time comercial do SAP insere um "Motivo de Recusa". Isso desativa o item para faturamento, mas a linha **permanece física no banco**. Mapear a eliminação via `ABRUV` limpa o Data Warehouse e impede que você reporte metas de vendas infladas por itens cancelados antes da entrega.
* **Tipos de Ordem (`AUART`):** Nem tudo na tabela `VBAK` é venda geradora de receita. Tipos de ordem como `TA` ou `OR` são vendas comuns, mas ordens como `RE` representam devoluções e `FD` representam entregas gratuitas. Alinhe com a controladoria para aplicar filtros ou categorizações explícitas baseadas em `AUART` no dashboard.
* **Gatilho de Pipeline Incremental:** As tabelas `VBAK` e `VBAP` crescem agressivamente. Para cargas diárias via CDC, monitore o campo `AEDAT` (Data da última alteração do cabeçalho) para capturar pedidos antigos que sofreram mudanças de preço ou quantidade na ponta operante do ERP.