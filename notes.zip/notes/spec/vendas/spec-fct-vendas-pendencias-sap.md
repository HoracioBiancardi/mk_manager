---
created: '2026-06-29T18:30:41.067758+00:00'
folder: spec/vendas
id: spec-fct-vendas-pendencias-sap
modified: '2026-06-29T20:28:38.909194+00:00'
status: ''
tags:
- spec
- sap
- vendas
- pendencias
title: Spec - fct_vendas_pendencias SAP
type: note
---
# Documentação Técnico-Comercial: Fato de Pendências de Vendas / Backlog (fct_vendas_pendencias)

Esta documentação detalha a especificação de dados e a arquitetura da **Tabela Fato de Pendências de Vendas (`fct_vendas_pendencias`)**, projetada para calcular em tempo real o saldo residual de pedidos de venda que ainda não foram atendidos pelo faturamento, expondo a carteira de entregas futuras e os atrasos logísticos da organização.

---

## 1. Fluxo de Integração e Cruzamento (Arquitetura em Blocos)

A visão de pendências exige o cruzamento completo da esteira SD. Partimos do item do pedido (`VBAP`), analisamos as datas e quantidades programadas para despacho na tabela de Divisões de Remessa (`VBEP`) e deduzimos o volume que já foi efetivamente transformado em Nota Fiscal na tabela de itens de faturamento (`VBRP`), ligando-as pelos ponteiros nativos de herança (`VGBEL` e `VGPOS`).

```
===================================================================================
[CAMADA SILVER: ENTRADA]         [CAMADA SILVER: CRONOGRAMA]      [CAMADA GOLD]
 Itens de Pedido Ativos           Divisões de Remessa              Fato Final
===================================================================================

 ┌──────────────────────┐
 │   silver.stg_vbap    │ ───┐
 └──────────────────────┘    │
                             ▼ (INNER JOIN via VBELN e MANDT)
                             ┌─────────────────────────┐
                             │     silver.stg_vbep     │ ───┐
                             └─────────────────────────┘    │
                                                            ▼ (LEFT JOIN via Fluxo Nativo)
                                                            ┌──────────────────────┐        ┌───────────────┐
                                                            │   silver.stg_vbrp    │ ─────> │   gold.fct_   │
                                                            └──────────────────────┘        │vendas_pendenc │
                                                                                            └───────────────┘
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `fct_vendas_pendencias` é a ferramenta de governança mais valiosa para as equipas de Operações, Logística e Supply Chain. Ela responde instantaneamente à pergunta: *"O que nós já vendemos, mas ainda temos a obrigação legal e física de entregar ao cliente?"*.

A granularidade deste modelo está definida ao nível de **Mandante, Pedido de Venda, Item do Pedido e Divisão de Remessa (`VBEP-MANDT` + `VBEP-VBELN` + `VBEP-POSNR` + `VBEP-ETENR`)**. A inclusão da divisão de remessa (`ETENR`) é mandatória porque o SAP permite que um único item de pedido de 100 unidades seja programado para entrega em 4 datas diferentes de 25 unidades cada. Avaliar a pendência sem descer ao nível de divisão quebraria o rastreamento do cronograma logístico.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária (SAP) | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **VBAP** | Documento de vendas: dados de item | Transacional | `MANDT`, `VBELN`, `POSNR` | Ponto de partida. Fornece os códigos de produtos, centros expedidores e o preço unitário líquido do contrato. |
| **VBEP** | Documento de vendas: dados de divisão de remessa | Transacional | `MANDT`, `VBELN`, `POSNR`, `ETENR` | Fornece a quantidade total que o SAP confirmou em stock para envio (`BMENG`) e a data planeada de entrega (`EDAT`). |
| **VBRP** | Documento de faturamento: dados de item | Transacional | `MANDT`, `VBELN`, `POSNR` | Fornece o histórico condensado do que já foi faturado para aquele pedido específico, atuando como o fator de subtracção do saldo. |

---

## 4. Principais Campos e Chaves de Relacionamento

Chaves de ligação (*Foreign Keys*) estruturadas para a conexão imediata com o ecossistema dimensional Star Schema na Gold:

| Campo SAP | Nome Técnico | Tabela Origem | Papel na Modelagem | Destino do Relacionamento (Star Schema) |
| :--- | :--- | :---: | :--- | :--- |
| **`sk_material`** | Hash Key Material | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_material.sk_material` |
| **`sk_centro`** | Hash Key Centro | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_centro.sk_centro` |
| **`MANDT`** | Mandante | VBEP | Controle de Ambiente | Filtro de isolamento de tenant |
| **`VBELN`** | Documento Vendas | VBEP | Chave Natural Comercial | Identificador do Pedido de Venda |
| **`POSNR`** | Item Ordem Vendas | VBEP | Chave Natural Comercial | Sequencial da linha do produto no pedido |
| **`ETENR`** | Divisão Remessa | VBEP | Chave Natural Logística | Identificador do desmembramento da entrega |

---

## 5. Campos de Métricas e Filtros de Controle

Atributos analíticos, métricas de saldo e horizontes temporais de tracking da carteira:

| Campo SAP | Nome Técnico | Tabela Origem | Tipo | Função no Relatório / Regra de Negócio |
| :---: | :---: | :---: | :---: | :--- |
| **`EDAT`** | Data da remessa | VBEP | DATE (DATS) | **Filtro Temporal.** Data limite prometida ao cliente para a entrega física chegar ao destino. |
| **`BMENG`** | Qtd. confirmada | VBEP | DECIMAL(15,3) | **Métrica.** Quantidade que o ERP validou e garantiu que será atendida pelo fluxo logístico. |
| **`FKIMG`** | Qtd. faturada | VBRP | DECIMAL(15,3) | **Métrica.** Volume que já foi transformado em Nota Fiscal e saiu da carteira pendente. |
| **`NETWR`** | Valor líquido item | VBAP | DECIMAL(15,2) | **Atributo de Preço.** Utilizado para calcular o preço unitário flutuante e valorizar o saldo financeiro em aberto. |
| **`KWMENG`** | Qtd. total do item | VBAP | DECIMAL(15,3) | **Atributo Volumétrico.** Quantidade total original do item para cálculo da fração de preço. |

---

## 6. Query SQL de Extração e Cálculo de Saldo (`fct_vendas_pendencias`)

```sql
-- ====================================================================================
-- PROCESSO: EXTRAÇÃO, CÁLCULO E MATERIALIZAÇÃO DO BACKLOG GOLD (fct_vendas_pendencias)
-- TECNOLOGIA: SQL Server
-- REGRAS: Subtracção de Saldos Faturados, Herança de Chaves e Cálculo de Atraso (OTD).
-- ====================================================================================

WITH CTE_Faturamento_Acumulado AS (
    -- Consolida o total faturado por item de pedido de origem, eliminando faturas canceladas
    SELECT 
        RP.MANDT AS mandt,
        LTRIM(RTRIM(RP.AUBEL)) AS id_pedido_origem,
        RP.AUPOS AS id_item_pedido_origem,
        SUM(ISNULL(RP.FKIMG, 0)) AS total_qtd_faturada
    FROM silver.stg_sap_vbrp AS RP
    INNER JOIN silver.stg_sap_vbrk AS RK 
        ON RP.VBELN = RK.VBELN 
        AND RP.MANDT = RK.MANDT
    WHERE 
        ISNULL(RK.FKSTO, '') = '' -- Ignora estornos/cancelamentos de Notas Fiscais
    GROUP BY 
        RP.MANDT, RP.AUBEL, RP.AUPOS
),

CTE_Base_Pendencia AS (
    -- Une o Pedido (VBAP) e suas divisões (VBEP) calculando o preço unitário do contrato
    SELECT 
        EP.MANDT AS mandt,
        EP.VBELN AS id_pedido,
        EP.POSNR AS id_item,
        EP.ETENR AS id_divisao,
        AP.MATNR AS id_material,
        AP.WERKS AS id_centro,
        CASE WHEN ISNULL(AP.KWMENG, 0) > 0 THEN (ISNULL(AP.NETWR, 0) / AP.KWMENG) ELSE 0 END AS preco_unitario_liquido,
        CONVERT(DATE, EP.EDAT) AS data_entrega_prometida,
        ISNULL(EP.BMENG, 0) AS qtd_confirmada_remessa
    FROM silver.stg_sap_vbep AS EP
    INNER JOIN silver.stg_sap_vbap AS AP 
        ON EP.VBELN = AP.VBELN 
        AND EP.POSNR = AP.POSNR 
        AND EP.MANDT = AP.MANDT
    WHERE 
        ISNULL(AP.ABRUV, '') = '' -- Exclui linhas recusadas/canceladas no comercial
)

SELECT 
    -- Geração de Surrogate Keys para acoplamento multidimensional
    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(B.mandt)), ''), '|',
            ISNULL(LTRIM(RTRIM(B.id_material)), '')
        )
    ), 2) AS [sk_material],

    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(B.mandt)), ''), '|',
            ISNULL(LTRIM(RTRIM(B.id_centro)), '')
        )
    ), 2) AS [sk_centro],

    -- Metadados e Chaves Naturais Logísticas
    B.mandt                      AS [Mandante],
    LTRIM(RTRIM(B.id_pedido))    AS [Numero_Pedido],
    B.id_item                    AS [Item_Pedido],
    B.id_divisao                 AS [Divisao_Remessa],
    B.data_entrega_prometida     AS [Data_Entrega_Prometida],
    
    -- Métricas de Fluxo Operacional
    B.qtd_confirmada_remessa     AS [Qtd_Confirmada_Logistica],
    
    -- Distribuição do Faturamento: Se a quantidade faturada geral cobrir esta partição, expõe o valor faturado
    -- Caso contrário, calcula o saldo residual de forma inteligente por partição
    CASE 
        WHEN (B.qtd_confirmada_remessa - ISNULL(F.total_qtd_faturada, 0)) > 0 
        THEN (B.qtd_confirmada_remessa - ISNULL(F.total_qtd_faturada, 0))
        ELSE 0 
    END AS [Qtd_Pendente_Backlog],

    -- Métrica Monetária: Volume Pendente valorizado ao preço líquido acordado com o cliente
    (CASE 
        WHEN (B.qtd_confirmada_remessa - ISNULL(F.total_qtd_faturada, 0)) > 0 
        THEN (B.qtd_confirmada_remessa - ISNULL(F.total_qtd_faturada, 0))
        ELSE 0 
     END * B.preco_unitario_liquido
    ) AS [Valor_Financeiro_Pendente_Backlog],

    -- Indicador de Alerta de Negócio: Pedido Atrasado (Data Prometida < Data de Hoje)
    CASE 
        WHEN B.data_entrega_prometida < CONVERT(DATE, GETDATE()) 
             AND (B.qtd_confirmada_remessa - ISNULL(F.total_qtd_faturada, 0)) > 0
        THEN 'Pedido em Atraso (Aging)'
        WHEN (B.qtd_confirmada_remessa - ISNULL(F.total_qtd_faturada, 0)) <= 0 
        THEN 'Atendido / Concluido'
        ELSE 'Carteira Regular (No Prazo)'
    END AS [Status_Envelhecimento_Backlog],

    -- Metadados de Auditoria
    GETDATE() AS [Data_Processamento_DW]

FROM CTE_Base_Pendencia AS B
LEFT JOIN CTE_Faturamento_Acumulado AS F 
    ON B.mandt = F.mandt 
    AND B.id_pedido = F.id_pedido_origem 
    AND B.id_item = F.id_item_pedido_origem
WHERE 
    -- Regra de Performance: Mantém na Gold apenas o que possui saldo a entregar ou foi concluído recentemente
    (B.qtd_confirmada_remessa - ISNULL(F.total_qtd_faturada, 0)) > 0
```

---

## 7. Resumo Executivo e Dicas de Ouro (Engenharia SAP)

* **O Segredo do Cálculo por Partição:** O maior desafio técnico de um pipeline de Backlog é que o Faturamento (`VBRP`) não sabe o que é uma divisão de remessa (`VBEP`), ele apenas fatura o item da `VBAP`. Ao criarmos a lógica de subtracção baseada no acumulado do item dentro das partições da `VBEP`, evitamos que o relatório exiba saldos distorcidos ou negativos quando ocorrem entregas parciais.
* **Indicador de Aging (Envelhecimento de Carteira):** O campo calculated `Status_Envelhecimento_Backlog` permite que a equipa de Logística crie um painel de "Atrasos Críticos". Se a `Data_Entrega_Prometida` já passou e a quantidade pendente é maior que zero, o BI dispara alertas automáticos para renegociação de prazos ou priorização na fila de carregamento do armazém.
* **Sincronismo de Carga (Gatilho de Otimização):** Como esta tabela fato consome dados gerados tanto na esteira de Vendas quanto na esteira de Faturamento, o seu orquestrador (Data Factory, Airflow ou dbt) deve executar a carga da `fct_vendas_pendencias` **obrigatoriamente por último**, garantindo que as tabelas *Silver* de origem já estejam 100% actualizadas com os últimos inputs do ERP SAP.