---
created: '2026-06-27T18:58:22.508279+00:00'
folder: spec/vendas
id: spec-fct-estoque-posicao-sap
modified: '2026-06-29T20:29:26.046333+00:00'
status: ''
tags:
- spec
- sap
- vendas
- estoque
title: Spec - fct_estoque_posicao SAP
type: note
---
# Documentação Técnico-Comercial: Fato de Posição de Estoque Atual (fct_estoque_posicao)

Esta documentação detalha a especificação de dados e a arquitetura da **Tabela Fato de Posição de Estoque (`fct_estoque_posicao`)**, projetada para refletir o saldo físico instantâneo, disponível, em transferência e bloqueado por Centro e Depósito no SAP ECC, permitindo o cálculo de valoração financeira e análises de ruptura comercial contra a carteira de pedidos.

---

## 1. Fluxo de Integração e Cruzamento (Arquitetura em Blocos)

A visão de saldos de inventário no SAP ECC é extraída a partir da tabela central de estoques por depósito (**MARD**), cruzando com a tabela de inventário avaliado (**MBEW**) para capturar os custos unitários corporativos e permitir a valoração monetária completa do armazém.

```
===================================================================================
[CAMADA SILVER: BASE CORE]       [CAMADA SILVER: CUSTOS]          [CAMADA GOLD]
 Posição Física / Saldos          Valoração Financeira             Fato Final
===================================================================================

 ┌──────────────────────┐
 │   silver.stg_mard    │ ───┐
 └──────────────────────┘    │
                             ▼ (INNER JOIN via MATNR, MANDT, WERKS/BWKEY)
                             ┌─────────────────────────┐        ┌───────────────┐
                             │     silver.stg_mbew     │ ─────> │ gold.fct_     │
                             └─────────────────────────┘        │estoque_posicao│
                                                                └───────────────┘
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `fct_estoque_posicao` funciona como uma foto de posição instantânea (*Snapshot Fact Table*). Diferente de tabelas fatos transacionais (como vendas e faturamento, que acumulam eventos históricos contínuos), o estoque representa o estado físico e contábil do inventário no exato momento da extração.

A granularidade deste modelo está definida ao nível de **Mandante, Material, Centro e Depósito (`MARD-MANDT` + `MARD-MATNR` + `MARD-WERKS` + `MARD-LGORT`)**. Esta quebra é obrigatória porque o mesmo SKU possui saldos operacionais e custos flutuantes independentes para cada planta logística e galpão de armazenagem física da companhia.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária (SAP) | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **MARD** | Estoques de material por centro/depósito | Posição / Saldo | `MANDT`, `MATNR`, `WERKS`, `LGORT` | Centraliza os volumes físicos de estoque divididos por status (livre, bloqueado, controle de qualidade, transferência). |
| **MBEW** | Avaliação do material | Dado Mestre / Custo | `MANDT`, `MATNR`, `BWKEY` | Fornece o preço médio móvel ou padrão do item para calcular o valor financeiro do inventário do centro. |

---

## 4. Principais Campos e Chaves de Relacionamento

Estes campos atuam como as chaves de ligação (*Foreign Keys*) para conectar a Fato de Estoque às dimensões e tabelas de controle do modelo Star Schema:

| Campo SAP | Nome Técnico | Tabela Origem | Papel na Modelagem | Destino do Relacionamento (Star Schema) |
| :--- | :--- | :---: | :--- | :--- |
| **`sk_material`** | Hash Key Material | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_material.sk_material` |
| **`sk_centro`** | Hash Key Centro | Calculado | Surrogate Key (Join) | Conecta com `gold.dim_centro.sk_centro` |
| **`MANDT`** | Mandante | MARD | Controle de Ambiente | Filtro de ambiente corporativo |
| **`MATNR`** | Material | MARD | Chave Natural Tratada | Link alternativo de auditoria para o SKU |
| **`WERKS`** | Centro | MARD | Chave Natural Tratada | Mapeia o Centro Logístico físico de armazenagem |
| **`LGORT`** | Depósito | MARD | Atributo Operacional | Mapeia a localização física/galpão interno |
| **`BWKEY`** | Área Avaliação | MBEW | Chave de Custos | Acoplamento financeiro (Equivalente ao `WERKS`) |

---

## 5. Campos de Métricas e Filtros de Controle

Campos quantitativos que determinam a disponibilidade física e financeira dos produtos em estoque:

| Campo SAP | Nome Técnico | Tabela Origem | Tipo | Função no Relatório / Regra de Negócio |
| :---: | :---: | :---: | :---: | :--- |
| **`LABST`** | Estoque utiliz. livre | MARD | DECIMAL(13,3) | **Métrica.** Saldo físico disponível e desimpedido para venda imediata. |
| **`UMLME`** | Estoque em transferência| MARD | DECIMAL(13,3) | **Métrica.** Saldo que já saiu de um centro mas ainda não teve a entrada física confirmada no destino. |
| **`INSME`** | Em controle de qualid. | MARD | DECIMAL(13,3) | **Métrica.** Saldo retido para análises do laboratório/qualidade (indisponível para venda). |
| **`SPEME`** | Estoque bloqueado | MARD | DECIMAL(13,3) | **Métrica.** Saldo avariado, vencido ou retido por travas fiscais e inventários. |
| **`VERPR`** | Preço médio móvel | MBEW | DECIMAL(11,2) | **Custo.** Valor unitário flutuante do material, baseado nas últimas compras do ERP. |
| **`STPRS`** | Preço padrão | MBEW | DECIMAL(11,2) | **Custo.** Valor unitário fixado em controladoria (usado se o preço móvel for zerado). |

---

## 6. Query SQL de Extração e Valoração (`fct_estoque_posicao`)

```sql
-- ====================================================================================
-- PROCESSO: EXTRAÇÃO E MATERIALIZAÇÃO DA FATO GOLD (fct_estoque_posicao)
-- TECNOLOGIA: SQL Server
-- REGRAS: Geração de Surrogate Keys, herança de Mandante e Regra de Custo Unificado.
-- ====================================================================================

SELECT
    -- Geração de Surrogate Keys alinhadas com as dimensões Gold
    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(MARD.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(MARD.MATNR)), '')
        )
    ), 2) AS [sk_material],

    CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 
        CONCAT(
            ISNULL(LTRIM(RTRIM(MARD.MANDT)), ''), '|',
            ISNULL(LTRIM(RTRIM(MARD.WERKS)), '')
        )
    ), 2) AS [sk_centro],

    -- Metadados e Chaves Naturais Tratadas (Sem zeros à esquerda)
    MARD.MANDT   AS [Mandante],
    CASE 
        WHEN ISNUMERIC(MARD.MATNR) = 1 
        THEN LTRIM(RTRIM(CONVERT(VARCHAR(18), CONVERT(BIGINT, MARD.MATNR))))
        ELSE LTRIM(RTRIM(MARD.MATNR))
    END AS [Codigo_Produto],
    LTRIM(RTRIM(MARD.WERKS))   AS [Codigo_Centro],
    LTRIM(RTRIM(MARD.LGORT))   AS [Codigo_Deposito],
     
    -- Métricas de Volumetria Física (Saldos Absolutos)
    ISNULL(MARD.LABST, 0)   AS [Qtd_Estoque_Livre_Utilizacao],
    ISNULL(MARD.INSME, 0)   AS [Qtd_Estoque_Em_Qualidade],
    ISNULL(MARD.SPEME, 0)   AS [Qtd_Estoque_Bloqueado_Avaria],
    ISNULL(MARD.UMLME, 0)   AS [Qtd_Estoque_Em_Transferencia],
    
    (ISNULL(MARD.LABST, 0) + ISNULL(MARD.INSME, 0) + ISNULL(MARD.SPEME, 0) + ISNULL(MARD.UMLME, 0)) AS [Qtd_Estoque_Fisico_Total],
     
    -- Regra de Negócio Extensiva para Definição do Custo Unitário SAP
    CASE  
        WHEN ISNULL(MBEW.VERPR, 0) > 0 THEN MBEW.VERPR 
        ELSE ISNULL(MBEW.STPRS, 0) 
    END AS [Valor_Custo_Unitario_SAP],
     
    -- Métricas Valoradas Monetariamente (Quantidade x Preço de Controle)
    ((ISNULL(MARD.LABST, 0) + ISNULL(MARD.INSME, 0) + ISNULL(MARD.SPEME, 0) + ISNULL(MARD.UMLME, 0)) * CASE WHEN ISNULL(MBEW.VERPR, 0) > 0 THEN MBEW.VERPR ELSE ISNULL(MBEW.STPRS, 0) END
    ) AS [Valor_Financeiro_Estoque_Total],

    -- Data de Referência do Snapshot de Carga
    GETDATE() AS [Data_Processamento_DW]

FROM silver.stg_sap_mard AS MARD
INNER JOIN silver.stg_sap_mbew AS MBEW 
    ON MARD.MATNR = MBEW.MATNR 
    AND MARD.MANDT = MBEW.MANDT
    AND MARD.WERKS = MBEW.BWKEY -- Mapeamento por Área de Avaliação do Centro
WHERE 
    (MARD.LABST > 0 OR MARD.INSME > 0 OR MARD.SPEME > 0 OR MARD.UMLME > 0) -- Otimização do Data Lake: Expura registros sem saldo real
```

---

## 7. Resumo Executivo e Dicas de Ouro (Engenharia SAP)

* **Prevenção contra Ruptura de Estoque (Out of Stock):** O maior ganho comercial deste modelo é permitir que o BI cruze em tempo real o estoque livre (`Qtd_Estoque_Livre_Utilizacao`) contra a carteira de pendências em aberto (`fct_vendas_pendencias`). Expressões DAX ou views SQL que apontem saldo negativo sinalizam urgência crítica para o time de planejamento de produção (PCP) ou compras.
* **Política de Controle de Preços (`V` vs `S`):** O SAP utiliza o campo `VPRSV` na `MBEW` para ditar se o material avalia por Preço Médio Móvel (`V` - *Variable*) ou Preço Padrão (`S` - *Standard*). O tratamento em `CASE WHEN` executado na query garante conformidade corporativa automática independente da categoria do produto extraído.
* **A Pegadinha da Administração de Lotes (Batch Management):** Se a corporação utiliza controle de lotes (rastreabilidade de validade de insumos ou químicos), os saldos da `MARD` virão consolidados. Se houver discrepância física pontual em relatórios de inventário na ponta, a esteira de engenharia deverá ser evoluída na camada Silver para ler a tabela **`MCHB`** (Estoque de material por lotes) em substituição da `MARD`.