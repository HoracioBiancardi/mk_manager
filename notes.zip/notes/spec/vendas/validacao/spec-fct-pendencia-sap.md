---
created: '2026-06-27T19:00:05.706512+00:00'
folder: spec/vendas/validacao
id: spec-fct-pendencia-sap
modified: '2026-06-29T18:12:04.686653+00:00'
status: ''
tags:
- spec
- sap
- pendencia
title: Spec - fct_pendencia SAP
type: note
---
# Documentação Técnico-Comercial: Fato de Carteira e Pendências com Inteligência de Estoque (fct_pendencia)

Esta documentação detalha a especificação de dados e a arquitetura avançada da **Tabela Fato de Pendências (`fct_pendencia`)**. Esta versão incorpora uma subquery segura de saldo de estoque livre consolidado por Centro, eliminando o risco de duplicidade cartesiana e permitindo ao Dashboard diagnosticar instantaneamente se o gargalo do pedido é físico (Falta de Estoque) ou administrativo (Crédito/Preço).

---

## 1. Fluxo de Tabelas da Fato

A visão de pendências mapeia os documentos de vendas ativos e cruza os status logísticos e financeiros. Para trazer o estoque de forma segura, o modelo consome uma visão agrupada da tabela **MARD** antes de realizar o acoplamento com o item do pedido (`VBAP`).

```mermaid
flowchart LR
    VBAP["[VBAP] (Pedido-Item)"] -->|1:1 - Chave VBELN| VBAK["[VBAK] (Pedido-Cab.)"]
    VBAP -->|1:1 - Chave VBELN + POSNR| VBUP["[VBUP] (Status-Item)"]
    VBAK -->|1:1 - Chave VBELN| VBUK["[VBUK] (Status-Cab.)"]
    VBAP -->|N:1 - Chave MATNR + WERKS| MARD_AGRUP["[MARD Agrupada] (Estoque Livre por Centro)"]
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `fct_pendencia` consolidada com estoque permite separar o Backlog em duas grandes vertentes operacionais: **Pendência Comercial/Burocrática** (o pedido está travado, mas o produto existe no galpão) e **Pendência de Suprimentos/Ruptura** (o pedido está liberado, mas a fábrica não produziu ou o estoque acabou).

A granularidade está definida ao nível de **Item do Pedido de Venda (`VBAP-VBELN` + `VBAP-POSNR`)**. O estoque é injetado via subquery sumarisada por Material e Centro, garantindo que o volume de estoque livre atue apenas como uma métrica de comparação lateral, sem inflar a quantidade pendente original do pedido.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **VBAP** | Documentos de vendas: dados de item | Transacional | `VBELN`, `POSNR` | Fornece os itens pedidos, quantidades pendentes e o centro expedidor da linha. |
| **VBAK** | Documentos de vendas: dados de cabeçalho | Transacional | `VBELN` | Fornece a Organização de Vendas (`VKORG`), Tipo de Documento (`AUART`) e Bloqueios de Remessa. |
| **VBUP** | Documentos de vendas: status do item | Transacional / Status | `VBELN`, `POSNR` | Filtra o saldo em aberto através do status de atendimento logístico (`LFSTA`). |
| **VBUK** | Documentos de vendas: status do cabeçalho | Transacional / Status | `VBELN` | Fornece o status de crédito global (`CMGST`) para identificar bloqueios financeiros. |
| **MARD** | Estoques por centro/depósito (Subquery) | Posição / Saldo | `MATNR`, `WERKS`, `LGORT` | Sumarisada ao nível de Centro para fornecer o estoque livre utilizável do produto. |

---

## 4. Principais Campos e Chaves de Relacionamento

Estes campos atuam como as chaves de ligação (*Foreign Keys*) para conectar a Fato de Pendências às Dimensões de Clientes e Produtos:

| Campo SAP | Nome Técnico | Tabela Origem | Papel na Modelagem | Destino do Relacionamento (Star Schema) |
| :--- | :--- | :---: | :--- | :--- |
| **`KUNNR`** | Cliente | VBAK | Chave de Ligação Comercial | Conecta com `dim_cliente.Codigo_Cliente` |
| **`VKORG`** | Org. Vendas | VBAK | Chave de Ligação Comercial | Conecta com `dim_cliente.Org_Vendas` |
| **`MATNR`** | Material | VBAP | Chave de Ligação Logística | Conecta com `dim_material.Codigo_Produto` |
| **`VBELN`** | Pedido de Venda | VBAK / VBAP | Identificador do Pedido | Exibição e agrupamento operacional |

---

## 5. Campos de Métricas e Filtros de Controle

Campos transacionais e flags de status utilizados para isolar a carteira real e calcular o diagnóstico de Causa Raiz:

| Campo SAP | Nome Técnico | Tabela Origem | Tipo | Regra de Controle / Função no Relatório |
| :---: | :---: | :---: | :---: | :--- |
| **`KWMENG`**| Qtd Pedida | VBAP | DECIMAL | **Métrica.** Volume físico que está aguardando atendimento/expedição. |
| **`LABST`** | Estoque Livre | MARD (Sub) | DECIMAL | **Métrica.** Saldo total livre do produto no Centro para cobrir o pedido. |
| **`LFSTA`** | Status Remessa | VBUP | CHAR (1) | **Flag.** Filtra apenas as linhas em aberto (`'A'`) ou parciais (`'B'`). |
| **`LIFSK`** | Bloqueio Remessa | VBAK | CHAR (2) | **Controle.** Avalia os códigos ativos de travas operacionais (`'30'`, `'Z8'`). |
| **`CMGST`** | Status Crédito | VBUK | CHAR (1) | **Controle.** Identifica os status `'B'` ou `'C'` para reter por fluxo de crédito. |
| **`ABGRU`** | Motivo de Recusa | VBAP | CHAR (2) | **Filtro.** Deve ser estritamente igual a Vazio (` `) para remover itens cancelados. |

---

## 6. Query SQL de Extração (`fct_pendencia_com_estoque`)

```sql
SELECT
     -- Chaves de Tempo e Localização Física
     VBAK.ERDAT   AS [Data_Criacao_Pedido],
     VBAP.WERKS   AS [Centro_Expedidor],
     
     -- Chaves Combinadas de Relacionamento (Star Schema)
     VBAK.KUNNR   AS [Codigo_Cliente],
     VBAK.VKORG   AS [Org_Vendas],
     VBAP.MATNR   AS [Codigo_Produto],
     
     -- Rastreabilidade Operacional
     VBAK.VBELN   AS [Pedido_Venda],
     VBAK.AUART   AS [Tipo_Documento],
     VBAP.POSNR   AS [Item_Pedido],
     
     -- Métricas Físicas Cruzadas (Demanda vs Disponibilidade)
     VBAP.KWMENG  AS [Quantidade_Pendente],
     ISNULL(ESTOQUE.Estoque_Livre_Centro, 0) AS [Estoque_Disponivel_Centro],
     
     -- Inteligência Avançada de Causa Raiz Cruzando Travas Administrativas e Estoque Físico
     CASE 
         WHEN VBUK.CMGST IN ('B', 'C') THEN 'Pendente: Retido por Crédito (Financeiro)'
         WHEN VBAK.LIFSK = '30'        THEN 'Pendente: Aguardando Aprovação de Preço'
         WHEN VBAK.LIFSK = 'Z8'        THEN 'Pendente: Erro de Cadastro (Cliente Incorreto)'
         WHEN ISNULL(ESTOQUE.Estoque_Livre_Centro, 0) < VBAP.KWMENG THEN 'Pendente: Logística (Ruptura de Estoque)'
         WHEN VBUP.LFSTA IN ('A', 'B') THEN 'Pendente: Logística (Disponível - Aguardando Separação/Carga)'
         ELSE 'Outros status em aberto'
     END AS [Causa_Raiz_Real]

FROM VBAP
INNER JOIN VBAK ON VBAP.VBELN = VBAK.VBELN
INNER JOIN VBUP ON VBAP.VBELN = VBUP.VBELN AND VBAP.POSNR = VBUP.POSNR
INNER JOIN VBUK ON VBAK.VBELN = VBUK.VBELN 

-- Subquery Segura para trazer o Estoque Totalizado por Centro (Evita Duplicidade de Depósitos)
LEFT JOIN (
    SELECT MATNR, WERKS, SUM(LABST) AS Estoque_Livre_Centro
    FROM MARD
    GROUP BY MATNR, WERKS
) AS ESTOQUE ON VBAP.MATNR = ESTOQUE.MATNR AND VBAP.WERKS = ESTOQUE.WERKS

WHERE VBAP.ABGRU = ' '                   -- Regra de Ouro 1: Ignora itens cancelados comercialmente
  AND VBUP.LFSTA IN ('A', 'B')           -- Regra de Ouro 2: Filtra apenas pendência física real
  AND VBAK.LIFSK <> 'Z1'                 -- Regra de Ouro 3: Expuga cancelamentos físicos da operação (Z1)
  AND VBAK.VBTYP IN ('C', 'I')           -- Regra de Ouro 4: Restringe a ordens firmes e bonificações
```

---

## 7. Resumo e Observações Finais

* **Diagnóstico de Ruptura Automatizado:** Reparou na evolução do `CASE WHEN`? Agora ele faz um teste lógico físico: se o pedido passou pelas travas de crédito, preço e cadastro, mas o estoque somado do centro (`Estoque_Livre_Centro`) for menor que a `Quantidade_Pendente`, o sistema carimba automaticamente o status como **"Ruptura de Estoque"**. Se houver saldo, ele muda para **"Aguardando Separação/Carga"**.
* **Blindagem Total Contra Duplicidade:** O uso do `LEFT JOIN` apontando para uma tabela interna agrupada com `SUM(LABST)` e `GROUP BY MATNR, WERKS` garante que o relacionamento com a `VBAP` permaneça estritamente de `N:1`. O número de linhas da sua Fato de Pendências não será alterado em nenhum cenário.
* **Ação Comercial Imediata:** Este modelo capacita o time de Customer Service a atuar como um resolvedor de problemas: pedidos marcados como "Aguardando Separação" que possuem estoque disponível podem ser cobrados imediatamente do encarregado de expedição do armazém.










