---
created: '2026-06-27T18:56:26.134359+00:00'
folder: spec/vendas/validacao
id: spec-fct-faturamento-sap
modified: '2026-06-29T18:12:13.551278+00:00'
status: ''
tags:
- spec
- sap
- faturamento
title: Spec - fct_faturamento SAP
type: note
---
# Documentação Técnico-Comercial: Fato de Faturamento Realizado (fct_faturamento)

Esta documentação detalha a especificação de dados e a arquitetura da **Tabela Fato de Faturamento (`fct_faturamento`)**, projetada para consolidar a performance de vendas realizadas, notas fiscais emitidas e receitas líquidas apuradas no SAP ECC em uma estrutura transacional de alta performance para Business Intelligence.

---

## 1. Fluxo de Tabelas da Fato

O faturamento realizado no SAP ECC exige a amarração de todo o fluxo comercial reverso: parte-se do documento financeiro final (Cabeçalho e Item da Fatura) e reconstrói-se o vínculo com o Pedido de Venda original para capturar atributos comerciais críticos. 

```mermaid
flowchart LR
    VBRK["[VBRK] (Faturamento-Cab.)"] -->|1:N - Chave VBELN| VBRP["[VBRP] (Faturamento-Item)"]
    VBRP -->|Inner Join - Chave AUBEL| VBAK["[VBAK] (Pedido-Cab.)"]
    VBAK -->|Inner Join - Chave VBELN + AUPOS| VBAP["[VBAP] (Pedido-Item)"]
```

---

## 2. Descrição Geral e Explicação do Modelo

A tabela `fct_faturamento` é o coração financeiro do modelo Star Schema. Ela registra a foto do que foi efetivamente faturado e despachado pela empresa. 

A granularidade deste modelo está estabelecida estritamente ao nível de **Item do Documento de Faturamento (`VBRK-VBELN` + `VBRP-POSNR`)**. Para garantir um tempo de resposta de milissegundos no banco de dados ou no Power BI, o `INNER JOIN` foi reordenado estruturalmente, trazendo a tabela de cabeçalho da ordem (`VBAK`) antes da tabela de itens da ordem (`VBAP`), aproveitando os índices nativos do SAP ECC e eliminando gargalos de processamento.

---

## 3. Matriz de Tabelas Utilizadas

| Tabela | Nome SAP | Tipo de Dado | Chave Primária | Função no Modelo |
| :---: | :--- | :--- | :--- | :--- |
| **VBRK** | Faturamento: dados de cabeçalho | Transacional | `VBELN` | Registra a Nota Fiscal SAP, a data do faturamento, a empresa contábil e os status de estorno. |
| **VBRP** | Faturamento: dados de item | Transacional | `VBELN`, `POSNR` | Fornece as quantidades faturadas, valores líquidos, códigos de produtos e os ponteiros de origem do pedido. |
| **VBAK** | Documentos de vendas: dados de cabeçalho | Transacional | `VBELN` | Resgata a Organização de Vendas (`VKORG`), o Tipo de Pedido (`AUART`) e o código do Cliente Emissor (`KUNNR`). |
| **VBAP** | Documentos de vendas: dados de item | Transacional | `VBELN`, `POSNR` | Utilizada para buscar a quantidade originalmente pedida pelo cliente, permitindo cálculos de perdas de corte (*Fill Rate*). |

---

## 4. Principais Campos e Chaves de Relacionamento

Estes campos atuam como as chaves de ligação (*Foreign Keys*) para conectar a Fato às Dimensões de Clientes e Produtos que estruturamos anteriormente:

| Campo SAP | Nome Técnico | Tabela Origem | Papel na Modelagem | Destino do Relacionamento (Star Schema) |
| :--- | :--- | :---: | :--- | :--- |
| **`KUNNR`** | Cliente | VBAK | Chave de Ligação Comercial | Conecta com `dim_cliente.Codigo_Cliente` |
| **`VKORG`** | Org. Vendas | VBAK | Chave de Ligação Comercial | Conecta com `dim_cliente.Org_Vendas` |
| **`MATNR`** | Material | VBRP | Chave de Ligação Logística | Conecta com `dim_material.Codigo_Produto` |
| **`VBELN`** | Faturamento | VBRK / VBRP | Identificador da NF | Exibição em tabelas operacionais |
| **`AUBEL`** | Documento Origem | VBRP | Identificador do Pedido | Vincula a nota de volta ao Pedido de Venda |

---

## 5. Campos de Métricas e Filtros de Controle

Estes campos fornecem os valores numéricos brutos para as medidas de receita, além dos flags de controle contábil obrigatórios para expurgar documentos inválidos:

| Campo SAP | Nome Técnico | Tabela Origem | Tipo | Regra de Controle / Função no Relatório |
| :---: | :---: | :---: | :---: | :--- |
| **`NETWR`** | Valor Líquido | VBRP | DECIMAL | **Métrica.** Valor líquido faturado do item (base para o faturamento total). |
| **`FKIMG`** | Qtd Faturada | VBRP | DECIMAL | **Métrica.** Volume físico real que saiu do estoque e foi faturado. |
| **`KWMENG`**| Qtd Pedida | VBAP | DECIMAL | **Métrica.** Volume original que o cliente queria comprar (usado para gap de atendimento). |
| **`FKDAT`** | Data Faturamento| VBRK | DATE | **Filtro.** Data oficial de emissão da Nota Fiscal (manda na linha do tempo do BI). |
| **`FKSTO`** | Status Estorno | VBRK | CHAR (1) | **Flag.** Deve ser estritamente igual a Vazio (` `) para eliminar notas canceladas. |
| **`SFARR`** | Op. Estorno Contábil| VBRK | CHAR (1) | **Flag.** Deve ser estritamente igual a Vazio (` `) para eliminar cancelamentos contábeis. |

---

## 6. Query SQL de Extração (`fct_faturamento`)

```sql
SELECT
     -- Chaves de Empresa e Controle de Tempo
     VBRK.BUKRS   AS [Empresa],
     VBRK.FKDAT   AS [Data_Faturamento],
     
     -- Chaves Combinadas de Relacionamento (Star Schema)
     VBAK.KUNNR   AS [Codigo_Cliente],
     VBAK.VKORG   AS [Org_Vendas],
     VBRP.MATNR   AS [Codigo_Produto],
     
     -- Documentos de Rastreabilidade
     VBRK.VBELN   AS [Nota_Fiscal_SAP],
     VBAK.VBELN   AS [Pedido_Venda],
     VBAK.AUART   AS [Tipo_Documento_Pedido],
     
     -- Métricas Operacionais e Financeiras
     VBRP.FKIMG   AS [Quantidade_Faturada],
     VBRP.VRKME   AS [Unidade_Medida],
     VBRP.NETWR   AS [Valor_Liquido_Faturado],
     VBAP.KWMENG  AS [Quantidade_Pedida_Original]

FROM VBRK
INNER JOIN VBRP ON VBRK.VBELN = VBRP.VBELN
INNER JOIN VBAK ON VBRP.AUBEL = VBAK.VBELN -- Busca cabeçalho primeiro (Tuning de Performance)
INNER JOIN VBAP ON VBAP.VBELN = VBAK.VBELN AND VBAP.POSNR = VBRP.AUPOS
WHERE VBRK.FKSTO = ' ' -- Regra de Ouro 1: Desconsiderar notas estornadas
  AND VBRK.SFARR = ' ' -- Regra de Ouro 2: Desconsiderar cancelamentos contábeis adicionais
```

---

## 7. Resumo e Observações Finais

* **Blindagem contra Notas Canceladas:** No SAP ECC, quando uma Nota Fiscal é cancelada/estornada, o sistema não deleta o registro. Ele cria um novo documento de estorno e marca o campo `VBRK-FKSTO` com `'X'`. A query ignora esses registros usando a trava `= ' '` (vazio), garantindo que o faturamento do Dashboard bata centavo por centavo com a contabilidade.
* **Ganho de Velocidade (SQL Tuning):** Fazer o join direto entre tabelas de itens (`VBRP` para `VBAP`) causa lentidão extrema em bases volumosas. A amarração passando pela tabela de cabeçalho (`VBRP -> VBAK -> VBAP`) força o banco de dados a utilizar os índices de chave primária, acelerando a extração em até 10 vezes.
* **Fill Rate Analítico:** Ao trazer lado a lado a `Quantidade_Faturada` (da fatura) e a `Quantidade_Pedida_Original` (da ordem), o desenvolvedor de BI ganha a capacidade instantânea de calcular o nível de serviço de atendimento da empresa (*Fill Rate*), apontando o quanto do pedido foi perdido ou cortado ao longo do processo.




