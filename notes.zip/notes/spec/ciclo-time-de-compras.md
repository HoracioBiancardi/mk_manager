---
created: '2026-06-25T12:35:20.645989+00:00'
folder: spec
id: ciclo-time-de-compras
modified: '2026-06-26T14:29:59.607112+00:00'
status: ''
tags:
- spec
- compras
- ciclotime
title: Ciclo Time de Compras
type: note
---


# Fluxo do Ciclo time de Compras do SAP
```mermaid
flowchart LR
    SO["Purchase<br/>Requisition"] --> DL["Purchase<br/>Order"]
    DL --> GI["Goods<br/>Receipt"]
    GI --> BL["Invoice"]
    BL --> PY["Payment"]
```



# 🧾 Ciclo de Compras SAP (MM) – Mapeamento Completo de Ingestão

## 🔁 Fluxo de Processo

```text
Requisição de Compra (PR)
        ↓
Aprovação da Requisição
        ↓
Pedido de Compra (PO)
        ↓
Liberação / Aprovação do Pedido
        ↓
Agendamento / Entrega Planejada
        ↓
Entrada de Mercadoria (GR)
        ↓
Entrada de Fatura (IR)
        ↓
Pagamento (FI)
```

---

# 🟡 1. Requisição de Compra (PR)

```text
📌 Objetivo: Capturar demanda interna
```

## Tabelas principais

```text
EBAN   -> Requisição de compra
EBKN   -> Atribuição contábil
```

## Tabelas auxiliares

```text
CDHDR  -> Histórico de alterações
CDPOS  -> Detalhe das alterações
T024   -> Grupo de compras
USR02  -> Usuário
USR21  -> Usuário (dados adicionais)
```

---

# 🟠 2. Pedido de Compra (PO)

```text
📌 Objetivo: Formalizar compra com fornecedor
```

## Tabelas principais

```text
EKKO -> Cabeçalho do pedido
EKPO -> Item do pedido
EKKN -> Atribuição contábil do item
```

---

# 🔴 3. Aprovação do Pedido

```text
📌 Objetivo: Workflow de aprovação
```

## Tabelas

```text
EKKO  -> Status de liberação (FRGKE, FRGSX)
CDHDR -> Data real de aprovação
CDPOS -> Mudanças
```

---

# 🟢 4. Entrega Planejada

```text
📌 Objetivo: Datas prometidas pelo fornecedor
```

## Tabelas

```text
EKET -> Schedule line (datas de entrega)
```

---

# 🔵 5. Recebimento de Mercadoria (GR)

```text
📌 Objetivo: Entrada física do material
```

## Tabelas principais

```text
EKBE -> Histórico do pedido (GR)
MSEG -> Documento de material (item)
MKPF -> Documento de material (cabeçalho)
```

---

# 🟣 6. Entrada de Fatura (IR)

```text
📌 Objetivo: Registro da fatura
```

## Tabelas principais

```text
EKBE -> Histórico (IR)
RSEG -> Item da fatura
RBKP -> Cabeçalho da fatura
```

---

# 🟤 7. Pagamento (FI)

```text
📌 Objetivo: Fechamento financeiro
```

## Tabelas principais

```text
BKPF -> Documento contábil (header)
BSEG -> Documento contábil (item)
```

---

# 🧩 8. Dimensões (Master Data)

## 👤 Fornecedor

```text
LFA1 -> Dados gerais
LFB1 -> Dados por empresa
LFM1 -> Dados por organização de compras
```

---

## 📦 Material

```text
MARA -> Dados gerais
MARC -> Dados por centro
MARD -> Estoque por depósito
MAKT -> Descrição do material
```

---

## 🏭 Estrutura Organizacional

```text
T001  -> Empresa
T001W -> Centro (plant)
T001L -> Depósito
```

---

## 🛒 Compras

```text
T024  -> Grupo de compras
T024E -> Organização de compras
```

---

## 💰 Controlling / Financeiro

```text
CSKS -> Centro de custo
AUFK -> Ordem interna
ANLA -> Ativo fixo
SKA1 -> Plano de contas
```

---

# 🔗 9. Relacionamentos principais

```text
EBAN.BANFN = EKPO.BANFN
EBAN.BNFPO = EKPO.BNFPO

EKKO.EBELN = EKPO.EBELN

EKPO.EBELN = EKBE.EBELN
EKPO.EBELP = EKBE.EBELP

EKPO.EBELN = EKET.EBELN
EKPO.EBELP = EKET.EBELP

EKKO.LIFNR = LFA1.LIFNR
EKPO.MATNR = MARA.MATNR
```

---

# 🧱 10. Lista Consolidada de Ingestão

## 🔥 Core (obrigatório)

```text
EBAN
EBKN
EKKO
EKPO
EKKN
EKET
EKBE
```

---

## ⚙️ Logística

```text
MSEG
MKPF
```

---

## 💳 Fatura

```text
RSEG
RBKP
```

---

## 💰 Financeiro

```text
BKPF
BSEG
```

---

## 👤 Master Data

```text
LFA1
LFB1
LFM1

MARA
MARC
MARD
MAKT
```

---

## 🏭 Estrutura

```text
T001
T001W
T001L
T024
T024E
```

---

## 📊 Controlling

```text
CSKS
AUFK
ANLA
SKA1
```

---

## 🔍 Auditoria / Workflow

```text
CDHDR
CDPOS
```

---

# 🎯 11. Estrutura de Fato (para dbt)

```text
fct_compras_ciclo_time
```

## Grão

```text
mandt + ebeln + ebelp
```

---

# 🚀 12. Observações críticas

```text
1. EKBE precisa tratamento (tem estorno e eventos diferentes)
2. Datas de aprovação reais -> CDHDR/CDPOS
3. EKET geralmente é a data correta de entrega
4. Recebimento pode ser parcial
5. Fatura pode ser parcial
```

---
``










# Campos que estão faltando para a analise

| Campo a adicionar            | Campo SAP             | Tabela SAP         |
| ---------------------------- | --------------------- | ------------------ |
| cod_fornecedor               | LIFNR                 | EKKO               |
| tp_contratacao               | KONNR                 | EKKO               |
| cod_condicao_pagto_negociada | ZTERM                 | EKKO               |
| vlr_previsto_pagamento       | NETWR                 | EKPO               |
| cod_condicao_pagto_realizada | ZTERM                 | BSAK               |
| vlr_efetivamente_pago        | DMBTR                 | BSAK               |
| dt_remessa_prevista          | LFDAT                 | EBAN               |
| fl_urgencia                  | Campo Z (customizado) | EBAN               |
| dt_ultima_aprovacao_rc       | Ainda não informado   | ZMMR03 ou CDHDR    |
| nm_responsavel_aprovacao_rc  | Ainda não informado   | ZMMR03 ou CDHDR    |
| dt_recebimento_fisico        | Ainda não informado   | MSEG / MKPF / ESSR |
| dt_lancamento_fiscal_miro    | Ainda não informado   | RSEG / RBKP        |
