---
created: '2026-06-25T11:58:57.004281+00:00'
folder: spec
id: ciclo-time-de-vendas-sap
modified: '2026-06-26T15:11:20.821706+00:00'
status: ''
tags:
- vendas
- ciclotime
- spec
title: Ciclo Time de Vendas (SAP)
type: note
---
# Especificação do ciclo time de vendas olhando para o SAP.

## Fluxo do ciclo do pedido.
```mermaid
flowchart LR
    SO["Sales Order<br/>Criação do pedido"] --> DL["Delivery<br/>Entrega"]
    DL --> GI["Goods Issue<br/>Saída de mercadoria"]
    GI --> BL["Billing<br/>Faturamento"]
    BL --> PY["Payment<br/>Recebimento"]
```

## 1. Pedido de venda (Sales Order)

| Tabela | Descrição                        |
| ------ | -------------------------------- |
| VBAK   | Cabeçalho do pedido              |
| VBAP   | Item do pedido                   |
| VBEP   | Datas de entrega (schedule line) |

### Contém:
- Data do pedido (ERDAT)
- Cliente (KUNNR)
- Material / quantidade

---

## 2. Entrega (Delivery / Shipment)
| Tabela | Descrição            |
| ------ | -------------------- |
| LIKP   | Cabeçalho da entrega |
| LIPS   | Item da entrega      |

### Contém:
- Data de saída planejada/real
- Quantidade entregue

---

## 3. Faturamento (Billing)
| Tabela | Descrição           |
| ------ | ------------------- |
| VBRK   | Cabeçalho da fatura |
| VBRP   | Item da fatura      |


### Contém:
- Data da fatura
- Valor faturado

---

## 4. Link entre tudo (ESSENCIAL)
| Tabela | Descrição                                        |
| ------ | ------------------------------------------------ |
| VBFA   | Fluxo de documentos (Order → Delivery → Invoice) |


### Essa aqui é CRÍTICA para você:
•	Relaciona todos os documentos do ciclo
•	Permite reconstruir o fluxo fim a fim

---

## 3. Relacionamento principal (join lógico)
Esse é o join clássico que você provavelmente vai implementar como fato:

VBAK (pedido)
  → VBAP (item)
    → VBFA (link)
      → LIKP / LIPS (entrega)
        → VBRK / VBRP (faturamento)

Ou simplificado:
VBAK → VBAP → VBFA → LIKP → LIPS → VBRK → VBRP

---

## 4. Métricas de cycle time que você consegue criar
Agora conectando com seu objetivo (analytics):
🔹 Lead time total
Data faturamento (VBRK.FKDAT) - Data pedido (VBAK.ERDAT)
🔹 Order → Delivery
Data entrega (LIKP.WADAT ou LFDAT) - Data pedido
🔹 Delivery → Billing
Data faturamento - Data entrega

---

## 5. Tabelas complementares (recomendado no seu cenário)
Como você já trabalha com modelagem SAP (nível senior), recomendo incluir:

👤 Cliente
•	KNA1 (dados gerais)
•	KNVV (dados de vendas)

📦 Material
•	MARA
•	MVKE

💰 Condições / valores
•	KONV (ou PRCD_ELEMENTS no S/4)

📊 Status
•	VBUK (status cabeçalho)
•	VBUP (status item)





```sql



with

/* -------------------------------------------------------------------------- */
/* 1. Pedido de venda - cabeçalho                                              */
/* -------------------------------------------------------------------------- */
vbak as (

    select
        vbak.mandt,
        vbak.vbeln                                      as pedido_venda,
        vbak.auart                                      as tipo_pedido_venda,
        vbak.vkorg                                      as organizacao_vendas,
        vbak.vtweg                                      as canal_distribuicao,
        vbak.spart                                      as setor_atividade,
        vbak.kunnr                                      as cliente_emissor_ordem,
        vbak.bstnk                                      as pedido_cliente,
        vbak.waerk                                      as moeda_pedido,
        vbak.netwr                                      as valor_liquido_pedido,

        cast(nullif(vbak.erdat, '00000000') as date)    as data_criacao_pedido,
        cast(nullif(vbak.audat, '00000000') as date)    as data_documento_pedido,
        cast(nullif(vbak.vdatu, '00000000') as date)    as data_entrega_solicitada,

        vbak.ernam                                      as usuario_criacao_pedido,
        vbak.vkgrp                                      as grupo_vendedores,
        vbak.vkbur                                      as escritorio_vendas,
        vbak.knumv                                      as numero_condicao_pedido

    from silver.dataspherev2.vbak as vbak

),

/* -------------------------------------------------------------------------- */
/* 2. Pedido de venda - item                                                   */
/* -------------------------------------------------------------------------- */
vbap as (

    select
        vbap.mandt,
        vbap.vbeln                                      as pedido_venda,
        vbap.posnr                                      as item_pedido_venda,
        vbap.matnr                                      as material,
        vbap.arktx                                      as descricao_item_pedido,
        vbap.pstyv                                      as categoria_item_pedido,
        vbap.werks                                      as centro,
        vbap.lgort                                      as deposito,
        vbap.charg                                      as lote,
        vbap.vrkme                                      as unidade_venda,
        vbap.kwmeng                                     as quantidade_pedido,
        vbap.netwr                                      as valor_liquido_item_pedido,
        vbap.waerk                                      as moeda_item_pedido,
        vbap.abgru                                      as motivo_recusa,
        vbap.vstel                                      as ponto_expedicao,
        vbap.route                                      as rota,
        vbap.spart                                      as setor_atividade_item

    from silver.dataspherev2.vbap as vbap

),

/* -------------------------------------------------------------------------- */
/* 3. Schedule line - datas e quantidades confirmadas                          */
/* -------------------------------------------------------------------------- */
vbep_agg as (

    select
        vbep.mandt,
        vbep.vbeln                                      as pedido_venda,
        vbep.posnr                                      as item_pedido_venda,

        min(cast(nullif(vbep.edatu, '00000000') as date)) as primeira_data_programada,
        max(cast(nullif(vbep.edatu, '00000000') as date)) as ultima_data_programada,

        sum(coalesce(vbep.wmeng, 0))                    as quantidade_programada,
        sum(coalesce(vbep.bmeng, 0))                    as quantidade_confirmada

    from silver.dataspherev2.vbep as vbep

    group by
        vbep.mandt,
        vbep.vbeln,
        vbep.posnr

),

/* -------------------------------------------------------------------------- */
/* 4. Status do pedido - cabeçalho                                             */
/* -------------------------------------------------------------------------- */
vbuk as (

    select
        vbuk.mandt,
        vbuk.vbeln                                      as pedido_venda,
        vbuk.gbstk                                      as status_global_cabecalho,
        vbuk.lfstk                                      as status_entrega_cabecalho,
        vbuk.fkstk                                      as status_faturamento_cabecalho,
        vbuk.cmgst                                      as status_credito_cabecalho

    from silver.dataspherev2.vbuk as vbuk

),

/* -------------------------------------------------------------------------- */
/* 5. Status do pedido - item                                                  */
/* -------------------------------------------------------------------------- */
vbup as (

    select
        vbup.mandt,
        vbup.vbeln                                      as pedido_venda,
        vbup.posnr                                      as item_pedido_venda,
        vbup.gbsta                                      as status_global_item,
        vbup.lfsta                                      as status_entrega_item,
        vbup.fksta                                      as status_faturamento_item

    from silver.dataspherev2.vbup as vbup

),

/* -------------------------------------------------------------------------- */
/* 6. Fluxo documental: pedido -> entrega                                      */
/* -------------------------------------------------------------------------- */
fluxo_pedido_entrega as (

    select
        vbfa.mandt,
        vbfa.vbelv                                      as pedido_venda,
        vbfa.posnv                                      as item_pedido_venda,
        vbfa.vbeln                                      as entrega,
        vbfa.posnn                                      as item_entrega,
        vbfa.vbtyp_v                                    as categoria_documento_origem,
        vbfa.vbtyp_n                                    as categoria_documento_destino,
        vbfa.rfmng                                      as quantidade_referenciada_entrega,
        vbfa.meins                                      as unidade_referenciada_entrega,

        cast(nullif(vbfa.erdat, '00000000') as date)    as data_criacao_fluxo_pedido_entrega

    from silver.dataspherev2.vbfa as vbfa

    where 1 = 1
        /*
            Fluxo SD:
            C = Sales Order
            J = Delivery

            Em alguns ambientes o tipo/categoria pode variar ou vir em branco
            dependendo da extração. Por isso mantemos também o join pelo
            documento de entrega na LIPS/LIKP depois.
        */
        and vbfa.vbeln is not null
        and vbfa.vbelv is not null
        and vbfa.posnv is not null
        and vbfa.posnn is not null
        and (
            vbfa.vbtyp_n = 'J'
            or vbfa.vbtyp_v = 'C'
        )

),

/* -------------------------------------------------------------------------- */
/* 7. Entrega - cabeçalho                                                      */
/* -------------------------------------------------------------------------- */
likp as (

    select
        likp.mandt,
        likp.vbeln                                      as entrega,
        likp.lfart                                      as tipo_entrega,
        likp.vstel                                      as ponto_expedicao_entrega,
        likp.route                                      as rota_entrega,
        likp.kunnr                                      as cliente_recebedor_entrega,

        cast(nullif(likp.erdat, '00000000') as date)    as data_criacao_entrega,
        cast(nullif(likp.lfdat, '00000000') as date)    as data_entrega_planejada,
        cast(nullif(likp.wadat, '00000000') as date)    as data_saida_mercadoria_planejada,
        cast(nullif(likp.wadat_ist, '00000000') as date) as data_saida_mercadoria_real,

        likp.ernam                                      as usuario_criacao_entrega

    from silver.dataspherev2.likp as likp

),

/* -------------------------------------------------------------------------- */
/* 8. Entrega - item                                                           */
/* -------------------------------------------------------------------------- */
lips as (

    select
        lips.mandt,
        lips.vbeln                                      as entrega,
        lips.posnr                                      as item_entrega,
        lips.vgbel                                      as pedido_venda_referencia,
        lips.vgpos                                      as item_pedido_venda_referencia,
        lips.matnr                                      as material_entrega,
        lips.werks                                      as centro_entrega,
        lips.lgort                                      as deposito_entrega,
        lips.charg                                      as lote_entrega,
        lips.vrkme                                      as unidade_entrega,
        lips.lfimg                                      as quantidade_entregue,
        lips.ntgew                                      as peso_liquido_entrega,
        lips.brgew                                      as peso_bruto_entrega,
        lips.gewei                                      as unidade_peso_entrega

    from silver.dataspherev2.lips as lips

),

/* -------------------------------------------------------------------------- */
/* 9. Fluxo documental: entrega -> faturamento                                 */
/* -------------------------------------------------------------------------- */
fluxo_entrega_faturamento as (

    select
        vbfa.mandt,
        vbfa.vbelv                                      as entrega,
        vbfa.posnv                                      as item_entrega,
        vbfa.vbeln                                      as documento_faturamento,
        vbfa.posnn                                      as item_documento_faturamento,
        vbfa.vbtyp_v                                    as categoria_documento_origem,
        vbfa.vbtyp_n                                    as categoria_documento_destino,
        vbfa.rfmng                                      as quantidade_referenciada_faturamento,
        vbfa.meins                                      as unidade_referenciada_faturamento,

        cast(nullif(vbfa.erdat, '00000000') as date)    as data_criacao_fluxo_entrega_faturamento

    from silver.dataspherev2.vbfa as vbfa

    where 1 = 1
        /*
            Fluxo SD:
            J = Delivery
            M = Billing Document
        */
        and vbfa.vbeln is not null
        and vbfa.vbelv is not null
        and vbfa.posnv is not null
        and vbfa.posnn is not null
        and (
            vbfa.vbtyp_v = 'J'
            or vbfa.vbtyp_n = 'M'
        )

),

/* -------------------------------------------------------------------------- */
/* 10. Fallback: pedido -> faturamento direto                                  */
/* -------------------------------------------------------------------------- */
fluxo_pedido_faturamento_direto as (

    select
        vbfa.mandt,
        vbfa.vbelv                                      as pedido_venda,
        vbfa.posnv                                      as item_pedido_venda,
        vbfa.vbeln                                      as documento_faturamento,
        vbfa.posnn                                      as item_documento_faturamento,
        vbfa.vbtyp_v                                    as categoria_documento_origem,
        vbfa.vbtyp_n                                    as categoria_documento_destino,
        vbfa.rfmng                                      as quantidade_referenciada_faturamento_direto,
        vbfa.meins                                      as unidade_referenciada_faturamento_direto,

        cast(nullif(vbfa.erdat, '00000000') as date)    as data_criacao_fluxo_pedido_faturamento

    from silver.dataspherev2.vbfa as vbfa

    where 1 = 1
        /*
            Alguns cenários podem faturar referenciando diretamente pedido,
            principalmente dependendo do tipo de documento/processo.
        */
        and vbfa.vbeln is not null
        and vbfa.vbelv is not null
        and vbfa.posnv is not null
        and vbfa.posnn is not null
        and (
            vbfa.vbtyp_v = 'C'
            and vbfa.vbtyp_n = 'M'
        )

),

/* -------------------------------------------------------------------------- */
/* 11. Faturamento - cabeçalho                                                 */
/* -------------------------------------------------------------------------- */
vbrk as (

    select
        vbrk.mandt,
        vbrk.vbeln                                      as documento_faturamento,
        vbrk.fkart                                      as tipo_faturamento,
        vbrk.vkorg                                      as organizacao_vendas_faturamento,
        vbrk.vtweg                                      as canal_distribuicao_faturamento,
        vbrk.spart                                      as setor_atividade_faturamento,
        vbrk.kunrg                                      as cliente_pagador,
        vbrk.kunag                                      as cliente_emissor_fatura,
        vbrk.waerk                                      as moeda_faturamento,
        vbrk.netwr                                      as valor_liquido_faturamento,
        vbrk.mwsbk                                      as valor_imposto_faturamento,
        vbrk.xblnr                                      as referencia_faturamento,
        vbrk.belnr                                      as documento_contabil,
        vbrk.gjahr                                      as exercicio_documento_contabil,

        cast(nullif(vbrk.erdat, '00000000') as date)    as data_criacao_faturamento,
        cast(nullif(vbrk.fkdat, '00000000') as date)    as data_faturamento,

        vbrk.ernam                                      as usuario_criacao_faturamento

    from silver.dataspherev2.vbrk as vbrk

),

/* -------------------------------------------------------------------------- */
/* 12. Faturamento - item                                                      */
/* -------------------------------------------------------------------------- */
vbrp as (

    select
        vbrp.mandt,
        vbrp.vbeln                                      as documento_faturamento,
        vbrp.posnr                                      as item_documento_faturamento,
        vbrp.vgbel                                      as documento_referencia_faturamento,
        vbrp.vgpos                                      as item_documento_referencia_faturamento,
        vbrp.aubel                                      as pedido_venda_referencia_faturamento,
        vbrp.aupos                                      as item_pedido_venda_referencia_faturamento,
        vbrp.matnr                                      as material_faturamento,
        vbrp.arktx                                      as descricao_item_faturamento,
        vbrp.werks                                      as centro_faturamento,
        vbrp.vrkme                                      as unidade_faturamento,
        vbrp.fkimg                                      as quantidade_faturada,
        vbrp.netwr                                      as valor_liquido_item_faturamento,
        vbrp.mwsbp                                      as valor_imposto_item_faturamento,
        vbrp.kzwi1                                      as subtotal_1,
        vbrp.kzwi2                                      as subtotal_2,
        vbrp.kzwi3                                      as subtotal_3,
        vbrp.kzwi4                                      as subtotal_4,
        vbrp.kzwi5                                      as subtotal_5,
        vbrp.kzwi6                                      as subtotal_6

    from silver.dataspherev2.vbrp as vbrp

),

/* -------------------------------------------------------------------------- */
/* 13. Cliente - dados gerais                                                  */
/* -------------------------------------------------------------------------- */
kna1 as (

    select
        kna1.mandt,
        kna1.kunnr                                      as cliente,
        kna1.name1                                      as nome_cliente,
        kna1.land1                                      as pais_cliente,
        kna1.regio                                      as regiao_cliente,
        kna1.ort01                                      as cidade_cliente,
        kna1.ktokd                                      as grupo_conta_cliente,
        kna1.stcd1                                      as cnpj_cpf_cliente

    from silver.dataspherev2.kna1 as kna1

),

/* -------------------------------------------------------------------------- */
/* 14. Cliente - área de vendas                                                */
/* -------------------------------------------------------------------------- */
knvv as (

    select
        knvv.mandt,
        knvv.kunnr                                      as cliente,
        knvv.vkorg                                      as organizacao_vendas,
        knvv.vtweg                                      as canal_distribuicao,
        knvv.spart                                      as setor_atividade,
        knvv.kdgrp                                      as grupo_cliente,
        knvv.bzirk                                      as regiao_vendas,
        knvv.vkgrp                                      as grupo_vendedores_cliente,
        knvv.vkbur                                      as escritorio_vendas_cliente,
        knvv.zterm                                      as condicao_pagamento_cliente,
        knvv.inco1                                      as incoterm_1,
        knvv.inco2                                      as incoterm_2

    from silver.dataspherev2.knvv as knvv

),

/* -------------------------------------------------------------------------- */
/* 15. Material - dados gerais                                                 */
/* -------------------------------------------------------------------------- */
mara as (

    select
        mara.mandt,
        mara.matnr                                      as material,
        mara.mtart                                      as tipo_material,
        mara.matkl                                      as grupo_mercadoria,
        mara.meins                                      as unidade_medida_basica,
        mara.spart                                      as setor_atividade_material,
        mara.prdha                                      as hierarquia_produto

    from silver.dataspherev2.mara as mara

),

/* -------------------------------------------------------------------------- */
/* 16. Material - descrição                                                    */
/* -------------------------------------------------------------------------- */
makt as (

    select
        makt.mandt,
        makt.matnr                                      as material,
        makt.spras                                      as idioma,
        makt.maktx                                      as descricao_material

    from silver.dataspherev2.makt as makt

    where makt.spras = 'P'

),

/* -------------------------------------------------------------------------- */
/* 17. Montagem do fluxo base                                                  */
/* -------------------------------------------------------------------------- */
base_cycle as (

    select
        vbak.mandt,
        vbak.pedido_venda,
        vbap.item_pedido_venda,

        fluxo_pedido_entrega.entrega,
        fluxo_pedido_entrega.item_entrega,

        coalesce(
            fluxo_entrega_faturamento.documento_faturamento,
            fluxo_pedido_faturamento_direto.documento_faturamento
        )                                               as documento_faturamento,

        coalesce(
            fluxo_entrega_faturamento.item_documento_faturamento,
            fluxo_pedido_faturamento_direto.item_documento_faturamento
        )                                               as item_documento_faturamento,

        vbak.tipo_pedido_venda,
        vbap.categoria_item_pedido,

        vbak.organizacao_vendas,
        vbak.canal_distribuicao,
        vbak.setor_atividade,
        vbak.grupo_vendedores,
        vbak.escritorio_vendas,

        vbak.cliente_emissor_ordem,
        likp.cliente_recebedor_entrega,
        vbrk.cliente_pagador,

        vbap.material,
        vbap.descricao_item_pedido,

        vbap.centro,
        vbap.deposito,
        vbap.lote,

        vbak.pedido_cliente,
        vbak.moeda_pedido,
        vbrk.moeda_faturamento,

        vbak.data_criacao_pedido,
        vbak.data_documento_pedido,
        vbak.data_entrega_solicitada,

        vbep_agg.primeira_data_programada,
        vbep_agg.ultima_data_programada,

        likp.data_criacao_entrega,
        likp.data_entrega_planejada,
        likp.data_saida_mercadoria_planejada,
        likp.data_saida_mercadoria_real,

        vbrk.data_criacao_faturamento,
        vbrk.data_faturamento,

        vbap.quantidade_pedido,
        vbep_agg.quantidade_programada,
        vbep_agg.quantidade_confirmada,
        lips.quantidade_entregue,
        vbrp.quantidade_faturada,

        vbap.unidade_venda,
        lips.unidade_entrega,
        vbrp.unidade_faturamento,

        vbap.valor_liquido_item_pedido,
        vbrp.valor_liquido_item_faturamento,
        vbrp.valor_imposto_item_faturamento,

        vbak.valor_liquido_pedido,
        vbrk.valor_liquido_faturamento,
        vbrk.valor_imposto_faturamento,

        vbap.motivo_recusa,

        vbuk.status_global_cabecalho,
        vbuk.status_entrega_cabecalho,
        vbuk.status_faturamento_cabecalho,
        vbuk.status_credito_cabecalho,

        vbup.status_global_item,
        vbup.status_entrega_item,
        vbup.status_faturamento_item,

        likp.tipo_entrega,
        vbrk.tipo_faturamento,
        vbrk.documento_contabil,
        vbrk.exercicio_documento_contabil,

        fluxo_pedido_entrega.quantidade_referenciada_entrega,
        fluxo_entrega_faturamento.quantidade_referenciada_faturamento,
        fluxo_pedido_faturamento_direto.quantidade_referenciada_faturamento_direto

    from vbak

    inner join vbap
        on vbak.mandt = vbap.mandt
        and vbak.pedido_venda = vbap.pedido_venda

    left join vbep_agg
        on vbap.mandt = vbep_agg.mandt
        and vbap.pedido_venda = vbep_agg.pedido_venda
        and vbap.item_pedido_venda = vbep_agg.item_pedido_venda

    left join vbuk
        on vbak.mandt = vbuk.mandt
        and vbak.pedido_venda = vbuk.pedido_venda

    left join vbup
        on vbap.mandt = vbup.mandt
        and vbap.pedido_venda = vbup.pedido_venda
        and vbap.item_pedido_venda = vbup.item_pedido_venda

    left join fluxo_pedido_entrega
        on vbap.mandt = fluxo_pedido_entrega.mandt
        and vbap.pedido_venda = fluxo_pedido_entrega.pedido_venda
        and vbap.item_pedido_venda = fluxo_pedido_entrega.item_pedido_venda

    left join lips
        on fluxo_pedido_entrega.mandt = lips.mandt
        and fluxo_pedido_entrega.entrega = lips.entrega
        and fluxo_pedido_entrega.item_entrega = lips.item_entrega

    left join likp
        on lips.mandt = likp.mandt
        and lips.entrega = likp.entrega

    left join fluxo_entrega_faturamento
        on lips.mandt = fluxo_entrega_faturamento.mandt
        and lips.entrega = fluxo_entrega_faturamento.entrega
        and lips.item_entrega = fluxo_entrega_faturamento.item_entrega

    left join fluxo_pedido_faturamento_direto
        on vbap.mandt = fluxo_pedido_faturamento_direto.mandt
        and vbap.pedido_venda = fluxo_pedido_faturamento_direto.pedido_venda
        and vbap.item_pedido_venda = fluxo_pedido_faturamento_direto.item_pedido_venda
        and fluxo_entrega_faturamento.documento_faturamento is null

    left join vbrp
        on coalesce(
            fluxo_entrega_faturamento.mandt,
            fluxo_pedido_faturamento_direto.mandt
        ) = vbrp.mandt
        and coalesce(
            fluxo_entrega_faturamento.documento_faturamento,
            fluxo_pedido_faturamento_direto.documento_faturamento
        ) = vbrp.documento_faturamento
        and coalesce(
            fluxo_entrega_faturamento.item_documento_faturamento,
            fluxo_pedido_faturamento_direto.item_documento_faturamento
        ) = vbrp.item_documento_faturamento

    left join vbrk
        on vbrp.mandt = vbrk.mandt
        and vbrp.documento_faturamento = vbrk.documento_faturamento

),

/* -------------------------------------------------------------------------- */
/* 18. Enriquecimento dimensional e métricas                                   */
/* -------------------------------------------------------------------------- */
final as (

    select
        convert(
            varchar(64),
            hashbytes(
                'SHA2_256',
                concat_ws(
                    '|',
                    cast(base_cycle.mandt as varchar(10)),
                    cast(base_cycle.pedido_venda as varchar(50)),
                    cast(base_cycle.item_pedido_venda as varchar(50)),
                    coalesce(cast(base_cycle.entrega as varchar(50)), 'sem_entrega'),
                    coalesce(cast(base_cycle.item_entrega as varchar(50)), 'sem_item_entrega'),
                    coalesce(cast(base_cycle.documento_faturamento as varchar(50)), 'sem_faturamento'),
                    coalesce(cast(base_cycle.item_documento_faturamento as varchar(50)), 'sem_item_faturamento')
                )
            ),
            2
        )                                               as sk_sales_cycle,

        base_cycle.mandt,
        base_cycle.pedido_venda,
        base_cycle.item_pedido_venda,
        base_cycle.entrega,
        base_cycle.item_entrega,
        base_cycle.documento_faturamento,
        base_cycle.item_documento_faturamento,

        base_cycle.tipo_pedido_venda,
        base_cycle.categoria_item_pedido,
        base_cycle.tipo_entrega,
        base_cycle.tipo_faturamento,

        base_cycle.organizacao_vendas,
        base_cycle.canal_distribuicao,
        base_cycle.setor_atividade,
        base_cycle.grupo_vendedores,
        base_cycle.escritorio_vendas,

        base_cycle.cliente_emissor_ordem,
        cliente_ordem.nome_cliente                      as nome_cliente_emissor_ordem,
        cliente_ordem.pais_cliente                      as pais_cliente_emissor_ordem,
        cliente_ordem.regiao_cliente                    as regiao_cliente_emissor_ordem,
        cliente_ordem.cidade_cliente                    as cidade_cliente_emissor_ordem,
        cliente_ordem.grupo_conta_cliente               as grupo_conta_cliente_emissor_ordem,
        cliente_ordem.cnpj_cpf_cliente                  as cnpj_cpf_cliente_emissor_ordem,

        base_cycle.cliente_recebedor_entrega,
        cliente_entrega.nome_cliente                    as nome_cliente_recebedor_entrega,

        base_cycle.cliente_pagador,
        cliente_pagador.nome_cliente                    as nome_cliente_pagador,

        knvv.grupo_cliente,
        knvv.regiao_vendas,
        knvv.condicao_pagamento_cliente,
        knvv.incoterm_1,
        knvv.incoterm_2,

        base_cycle.material,
        coalesce(makt.descricao_material, base_cycle.descricao_item_pedido) as descricao_material,
        mara.tipo_material,
        mara.grupo_mercadoria,
        mara.hierarquia_produto,
        mara.unidade_medida_basica,

        base_cycle.centro,
        base_cycle.deposito,
        base_cycle.lote,

        base_cycle.pedido_cliente,
        base_cycle.moeda_pedido,
        base_cycle.moeda_faturamento,

        base_cycle.data_criacao_pedido,
        base_cycle.data_documento_pedido,
        base_cycle.data_entrega_solicitada,
        base_cycle.primeira_data_programada,
        base_cycle.ultima_data_programada,

        base_cycle.data_criacao_entrega,
        base_cycle.data_entrega_planejada,
        base_cycle.data_saida_mercadoria_planejada,
        base_cycle.data_saida_mercadoria_real,

        base_cycle.data_criacao_faturamento,
        base_cycle.data_faturamento,

        base_cycle.quantidade_pedido,
        base_cycle.quantidade_programada,
        base_cycle.quantidade_confirmada,
        base_cycle.quantidade_entregue,
        base_cycle.quantidade_faturada,

        base_cycle.unidade_venda,
        base_cycle.unidade_entrega,
        base_cycle.unidade_faturamento,

        base_cycle.valor_liquido_item_pedido,
        base_cycle.valor_liquido_item_faturamento,
        base_cycle.valor_imposto_item_faturamento,
        base_cycle.valor_liquido_pedido,
        base_cycle.valor_liquido_faturamento,
        base_cycle.valor_imposto_faturamento,

        base_cycle.motivo_recusa,

        base_cycle.status_global_cabecalho,
        base_cycle.status_entrega_cabecalho,
        base_cycle.status_faturamento_cabecalho,
        base_cycle.status_credito_cabecalho,

        base_cycle.status_global_item,
        base_cycle.status_entrega_item,
        base_cycle.status_faturamento_item,

        base_cycle.documento_contabil,
        base_cycle.exercicio_documento_contabil,

        base_cycle.quantidade_referenciada_entrega,
        base_cycle.quantidade_referenciada_faturamento,
        base_cycle.quantidade_referenciada_faturamento_direto,

        /* ------------------------------------------------------------------ */
        /* Métricas de cycle time                                               */
        /* ------------------------------------------------------------------ */

        case
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_criacao_entrega is not null
                then datediff(day, base_cycle.data_criacao_pedido, base_cycle.data_criacao_entrega)
        end                                             as dias_pedido_ate_criacao_entrega,

        case
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_saida_mercadoria_real is not null
                then datediff(day, base_cycle.data_criacao_pedido, base_cycle.data_saida_mercadoria_real)
        end                                             as dias_pedido_ate_saida_mercadoria,

        case
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_faturamento is not null
                then datediff(day, base_cycle.data_criacao_pedido, base_cycle.data_faturamento)
        end                                             as dias_pedido_ate_faturamento,

        case
            when base_cycle.data_criacao_entrega is not null
                and base_cycle.data_saida_mercadoria_real is not null
                then datediff(day, base_cycle.data_criacao_entrega, base_cycle.data_saida_mercadoria_real)
        end                                             as dias_criacao_entrega_ate_saida_mercadoria,

        case
            when base_cycle.data_saida_mercadoria_real is not null
                and base_cycle.data_faturamento is not null
                then datediff(day, base_cycle.data_saida_mercadoria_real, base_cycle.data_faturamento)
        end                                             as dias_saida_mercadoria_ate_faturamento,

        case
            when base_cycle.data_criacao_entrega is not null
                and base_cycle.data_faturamento is not null
                then datediff(day, base_cycle.data_criacao_entrega, base_cycle.data_faturamento)
        end                                             as dias_entrega_ate_faturamento,

        case
            when base_cycle.data_entrega_solicitada is not null
                and base_cycle.data_saida_mercadoria_real is not null
                then datediff(day, base_cycle.data_entrega_solicitada, base_cycle.data_saida_mercadoria_real)
        end                                             as dias_atraso_vs_data_solicitada,

        case
            when base_cycle.primeira_data_programada is not null
                and base_cycle.data_saida_mercadoria_real is not null
                then datediff(day, base_cycle.primeira_data_programada, base_cycle.data_saida_mercadoria_real)
        end                                             as dias_atraso_vs_primeira_data_programada,

        case
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_faturamento is not null
                then 1
            else 0
        end                                             as flag_ciclo_faturado,

        case
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_criacao_entrega is not null
                then 1
            else 0
        end                                             as flag_ciclo_com_entrega,

        case
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_criacao_entrega is null
                then 1
            else 0
        end                                             as flag_pedido_sem_entrega,

        case
            when base_cycle.data_criacao_entrega is not null
                and base_cycle.data_faturamento is null
                then 1
            else 0
        end                                             as flag_entrega_sem_faturamento,

        case
            when base_cycle.motivo_recusa is not null
                and ltrim(rtrim(base_cycle.motivo_recusa)) <> ''
                then 1
            else 0
        end                                             as flag_item_recusado,

        case
            when base_cycle.quantidade_pedido > 0
                and coalesce(base_cycle.quantidade_entregue, 0) >= base_cycle.quantidade_pedido
                then 1
            else 0
        end                                             as flag_quantidade_totalmente_entregue,

        case
            when base_cycle.quantidade_pedido > 0
                and coalesce(base_cycle.quantidade_faturada, 0) >= base_cycle.quantidade_pedido
                then 1
            else 0
        end                                             as flag_quantidade_totalmente_faturada,

        case
            when base_cycle.data_entrega_solicitada is not null
                and base_cycle.data_saida_mercadoria_real is not null
                and base_cycle.data_saida_mercadoria_real > base_cycle.data_entrega_solicitada
                then 1
            else 0
        end                                             as flag_entrega_atrasada,

        case
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_faturamento is not null
                and datediff(day, base_cycle.data_criacao_pedido, base_cycle.data_faturamento) <= 2
                then '00-02 dias'
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_faturamento is not null
                and datediff(day, base_cycle.data_criacao_pedido, base_cycle.data_faturamento) between 3 and 5
                then '03-05 dias'
            when base_cycle.data_criacao_pedido is not null
                and base_cycle.data_faturamento is not null
                and datediff(day, base_cycle.data_criacao_pedido, base_cycle.data_faturamento) between 6 and 10
                then '06-10 dias'













```
