---
created: '2026-06-24T20:50:47.915320+00:00'
folder: spec
id: iqvia
modified: '2026-06-26T15:09:58.185252+00:00'
status: ''
tags:
- spec
- iqvia
title: IQVIA
type: note
---
# MDTR – Monitor Distribution Tracker

É uma ferramenta de auditoria que mede a demanda real de um laboratório por meio de informações de distribuidores, redes de farmácias e serviços de delivery, coletadas pela IMS Health. 
Permite mensuração por níveis geográficos, como UF, cidade, setor, bricks, CEPs e CNPJs. 
Aplica técnicas de smoothing para suavizar tendências: até 15 dias é feita projeção com base no trimestre anterior; de 16 a 31 dias utiliza dados do mês anterior; acima de 2 meses sem dados, o distribuidor é suspenso do painel. 
Focado em sell-out (vendas no ponto de consumo), é ideal para comparar o desempenho do portfólio em diferentes farmácias do setor.

# DDD – Drug Distribution Data

Informa sobre o sell-in (vendas dos distribuidores para canais), geralmente com nível subnacional. 
Relatório mensal que mostra todo o volume de vendas de um laboratório e seus concorrentes em uma área definida (cidade, bairro), acumulado no período de 12 meses. 
Serve para mensurar o resultado de vendas e orientar estratégias para estimular demanda no setor. 


# NDDD – New Drugs Distribution Data

O NDDD (também chamado de New Drugs Distribution Data), conforme listado nas principais auditorias do setor, monitora a distribuição de novos medicamentos no mercado.
Utilizado para acompanhar o volume e a penetração inicial de lançamentos, geralmente em fases precoces do ciclo de vida de um produto.






O DDD mostra o que está sendo enviado aos canais (entrada de produtos).
O MDTR dá visibilidade do que está efetivamente sendo vendido nos pontos de venda.
O NDDD foca nos novos lançamentos, ajudando a monitorar sua penetração e aceitação no mercado.