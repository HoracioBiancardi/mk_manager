---
created: '2026-06-25T18:20:33.187029+00:00'
folder: analise
id: vendas-devolucoes
modified: '2026-06-26T15:08:35.098073+00:00'
status: ''
tags:
- analise
- vendas
- devolucao
title: Vendas (Devoluções)
type: note
---
Dentro do SAP tem um sistema de integração chamado Cockpit, onde mandamos as informações do SAP >> Salesforce e em alguns casos enviamos informações do Salesforce >> SAP

Na integração do sistema de Faturamento só temos a integração do SAP >> Salesforce
Com isso só enviamos dados do SAP para o salesforce e não o caminho inverso.

Perante a analise, foi estabelecido que temos uma problema com a integração, pois não conseguimos através dela identificar os campos que correlaciona a nota de devolução com a nota de origem podendo ocasionar problemas.
Isso so olhando para o salesforce. 
Conseguimos sim quando olhamos so para o SAP. 



# Alguns pontos que foi analisado. 

# 📊 SAP – Identificação da Nota Fiscal de Referência em Devoluções

## 🎯 Objetivo

Documentar a forma correta de identificar a **nota fiscal original (referência)** em cenários de **devolução de pedidos de compra/venda no SAP**, garantindo rastreabilidade consistente para modelagem analítica (dbt / Data Lake / DW).

---

## ❌ Abordagem Incorreta

### 🔹 Uso de `VBAK-XBLNR`

- Campo: **Referência externa**
- Tipo: Texto livre
- Problemas:
  - Não padronizado
  - Nem sempre preenchido
  - Pode conter qualquer valor (não apenas NF)

👉 **Conclusão:** Não deve ser utilizado para rastreabilidade entre documentos SAP.

---

## ✅ Abordagem Correta

### 🔹 Tabela `VBFA` (Fluxo de Documentos)

A tabela **VBFA** é a única fonte confiável para navegação entre documentos SAP.

### 📌 Campos relevantes

- `VBELN` → Documento atual  
- `VBELV` → Documento anterior  
- `VBTYP_N` → Tipo do documento atual  
- `VBTYP_V` → Tipo do documento anterior  

---

## 🔄 Modelo de Fluxo (Exemplo)

```
Fatura original (Billing - F2)
    ↓
Pedido de devolução (RE)
    ↓
Entrega de devolução (LR)
    ↓
Fatura de devolução (Credit Memo)
```

⚠️ O fluxo pode variar dependendo do processo da empresa.

---

## 🔍 Como identificar a NF original

A partir da devolução, deve-se navegar no fluxo até encontrar:

- Documento de faturamento (`Billing`)
- Ou documento contábil (FI)

### ✔️ Regra geral

- Percorrer `VBFA` recursivamente  
- Parar quando encontrar:  
  - `VBTYP = 'M'` (Billing)

---

## 🧠 Leitura Recursiva (Obrigatória)

Em cenários reais, a relação não é direta.

Exemplo:

```
Devolução
  → Entrega devolução
     → Pedido devolução
        → Fatura original
```

👉 Portanto, pode haver múltiplos níveis de profundidade.

---

## 🧾 Exemplo SQL (Recursivo)

```sql
WITH fluxo AS (

    SELECT
        vbfa.VBELN,
        vbfa.VBELV,
        vbfa.VBTYP_N,
        vbfa.VBTYP_V,
        1 AS nivel
    FROM VBFA vbfa
    WHERE vbfa.VBELN = '<doc_devolucao>'

    UNION ALL

    SELECT
        vbfa.VBELN,
        vbfa.VBELV,
        vbfa.VBTYP_N,
        vbfa.VBTYP_V,
        f.nivel + 1
    FROM VBFA vbfa
    INNER JOIN fluxo f
        ON vbfa.VBELN = f.VBELV
)

SELECT *
FROM fluxo
WHERE VBTYP_V = 'M'
```

---

## 🔗 Integração com FI (Nota Fiscal Contábil)

Para chegar até o documento FI:

```
VBFA → VBRK → BKPF
```

### 📌 Relacionamentos

- `VBFA-VBELV → VBRK-VBELN`  
- `VBRK-BELNR → BKPF-BELNR`  

---

## 🧱 Boas Práticas para Data Engineering

### ✅ Criar tabela derivada (Gold)

Sugestão:

```
fct_document_flow_enriched
```

### 📌 Campos recomendados

- documento atual  
- documento anterior  
- documento raiz (NF original)  
- tipo documento raiz  
- nível do fluxo  
- caminho completo  

---

## 🚀 Benefícios

- Evita recursão em tempo de consulta  
- Melhora performance  
- Garante rastreabilidade consistente  

---

## ✅ Resumo

| Abordagem     | Resultado        |
|---------------|------------------|
| VBAK-XBLNR    | ❌ Não confiável |
| VBRK-XBLNR    | ⚠️ Limitado      |
| VBFA          | ✅ Correto       |
| Recursividade | ✅ Necessária    |

---

## 🧠 Insight Final

A lógica correta no SAP **não está nos campos de referência**, mas sim no **modelo de fluxo de documentos (VBFA)**.

👉 Sempre pense em termos de grafo (document lineage), não relação direta.

---

## 📌 Evoluções sugeridas

- dbt (silver/gold)  
- materialização incremental  
- flatten completo do fluxo  
- camada semântica para BI  

---

**Autor:** Engenharia de Dados / Analytics


