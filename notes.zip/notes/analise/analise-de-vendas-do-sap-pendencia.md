---
created: '2026-06-26T16:36:28.995864+00:00'
folder: analise
id: analise-de-vendas-do-sap-pendencia
modified: '2026-06-27T18:40:24.498996+00:00'
status: ''
tags: []
title: Analise de vendas do SAP | Pendência
type: note
---
# Arquitetura de Dados SAP ECC: Visão de Ponta a Ponta, Vendas, Faturamento e Pendências

Este documento detalha a estrutura de tabelas do SAP ECC para mapear o fluxo comercial completo, criar visões segregadas de performance e gargalos, além de responder como o estoque impacta essa dinâmica.

---

## 1. Visão Completa e Integrada (O Fluxo de Ponta a Ponta)

No SAP ECC, o processo comercial se move através de documentos sequenciais. O segredo para amarrar todo o fluxo está na tabela de ligação **VBFA** (Fluxo de Documentos Comerciais).

### Diagrama de Relacionamento de Tabelas

```mermaid
flowchart LR
    VBAK["[VBAK] (Ordem-Cab.)"] --> VBAP["[VBAP] (Ordem-Item)"] --> VBUP["[VBUP] (Status do Item)"]
 
    VBAP --> VBFA["[VBFA] (Fluxo de Documentos)"] --> LIPS["[LIPS] (Remessa-Item)"] --> VBRP["[VBRP] (Faturamento-Item)"] --> VBRK["[VBRK] (Faturamento-Cab.)"]
    E["[LQUA][MARD] (Estoque)"] --> LIPS
    VBAK --> VBUK["[VBUK] (Status-Cab.) "]
```

### Dicionário de Tabelas do Fluxo Completo

| Tabela | Nome SAP | Tipo de Dado | Chave Primária Principal | Críticos para o Fluxo |
| :--- | :--- | :--- | :--- | :--- |
| **VBAK** | Documentos de vendas: Dados de cabeçalho | Transacional | `VBELN` (Nº Documento) | `ERDAT` (Data), `AUART` (Tipo Pedido), `KUNNR` (Emissor da Ordem), `NETWR` (Valor Líquido) |
| **VBAP** | Documentos de vendas: Dados de item | Transacional | `VBELN`, `POSNR` (Item) | `MATNR` (Material), `KWMENG` (Qtd Pedida), `WERKS` (Centro), `LGORT` (Depósito), `ABGRU` (Recusa) |
| **VBUP** | Documentos de vendas: Status do item | Transacional / Status | `VBELN`, `POSNR` | `LFSTA` (Status Remessa), `FKSTA` (Status Faturamento), `ABSTA` (Status Rejeição) |
| **VBFA** | Fluxo de documentos comerciais | Ligação (Histórico) | `VBELN_N`, `POSNN` | `VBELN_V` (Doc. Origem), `POSNV` (Item Origem), `VBTYP_N` (Tipo Doc. Posterior: `J`=Remessa, `M`=Fatura) |
| **LIPS** | Documento de fornecimento: Dados de item | Transacional | `VBELN`, `POSNR` | `LFIMG` (Qtd Fornecida), `MATNR` (Material), `WERKS` (Centro), `VGBEL` (Doc. Origem), `VGPOS` (Item Origem) |
| **VBRP** | Faturamento: Dados de item | Transacional | `VBELN`, `POSNR` | `FKIMG` (Qtd Faturada), `NETWR` (Valor Item), `AUBEL` (Pedido Origem), `AUPOS` (Item Pedido Origem) |
| **VBRK** | Faturamento: Dados de cabeçalho | Transacional | `VBELN` (Nº Fatura) | `FKDAT` (Data Faturamento), `BUKRS` (Empresa), `KUNRG` (Pagador) |

---

## 2. Gabarito de Controle Definitivo: Campos e Valores Reais da Operação

Abaixo estão centralizados apenas os campos de controle com movimentação real identificada no banco de dados, otimizando o processamento de regras.

| Tabela Origem | Campo | Nome Técnico | O que controla no Fluxo? | Valores Importantes e Textos Reais da Operação |
| :---: | :---: | :--- | :--- | :--- |
| **VBAK** | `VBTYP` | Categ.doc.comerc. | Identifica la naturaleza del documento en el cabeçalho. | • **`C`** = Ordem (Pedido Firme)<br>• **`I`** = Ordem gratuita (Amostra/Bonificação)<br>• **`H`** = Devolução<br>• **`B`** = Cotação *(Ignorar no Backlog)*<br>• **`G`** = Contrato *(Ignorar no Backlog)* |
| **VBAK** | `LIFSK` | Bloqueio remessa | Trava manual ou automática que impede a saída física da mercadoria. | • **Vazio (` `)** = Liberado para Logística<br>• **`30`** = Autoriz.modif.preço (Bloqueio de Margem)<br>• **`Z8`** = Cod.produto iincorre (Erro de Cadastro)<br>• **`Z1`** = Pedido Cancelado *(Expurgar do Backlog)* |
| **VBAK** / **VBAP** | `FAKSK` / `FAKSP` | Bloqueio faturamento | Trava que impede a emissão da Nota Fiscal. | • **Vazio (` `)** = Liberado para Faturamento<br>• **`01`** = Falta cálculo-custos<br>• **`03`** = Preço incompleto<br>• **`04`** = Verif.condiç.pagto.<br>• **`30`** = Autoriz.modif.preço |
| **VBAP** | `ABGRU` | Motivo de recusa | Cancelamento comercial definitivo daquela linha de produto. | • **Vazio (` `)** = Item Ativo / Venda Firme<br>• **Qualquer código preenchido** = Item Cancelado *(Expurgar do Backlog)* |
| **VBUK** | `CMGST` | Status crédito tot. | O termômetro financeiro do pedido. Bloqueia a esteira caso haja risco. | • **Vazio (` `)** = Sem verificação (ex: Amostras)<br>• **`A`** = Verif.crédito foi efetuada, operação oK<br>• **`B`** = Verif.crédito foi efetuada, operação não oK *(Preso)*<br>• **`C`** = Verif.crédito efetuada, operação não oK, liberação parcial<br>• **`D`** = Operação liberada pelo responsável crédito *(Liberado na VKM1)* |
| **VBUK** | `LFSTK` | Status de remessa | Mede o atendimento logístico a nível de cabeçalho. | • **`A`** = Não processado *(100% em aberto)*<br>• **`B`** = Processado parcialmente *(Tem saldo pendente)*<br>• **`C`** = Processado completamente *(Encerrado)* |
| **VBUK** | `ABSTK` | Status rejeição gl. | Consolida se houve cancelamentos no pedido. | • **`A`** = Não processado (Nenhuma linha cancelada)<br>• **`B`** = Processado parcialmente<br>• **`C`** = Processado completamente |
| **VBUK** | `GBSTK` | Status global doc. | O ciclo de vida geral da ordem dentro do SAP. | • **`A`** = Não processado<br>• **`B`** = Processado parcialmente<br>• **`C`** = Processado completamente *(Encerrado por entrega ou recusa)* |
| **VBUP** | `LFSTA` | Status remessa (Item)| Mede a pendência física e logística da linha do produto. | • **`A`** = Não processado *(Item pendente de envio)*<br>• **`B`** = Processado parcialmente *(Item tem saldo de envio)*<br>• **`C`** = Processado completamente *(Item totalmente expedido)* |
| **VBUP** | `FKSTA` | Status fatura (Item) | Mede se o produto já virou Nota Fiscal de verdade. | • **`A`** = Não processado *(Pendente de Faturamento)*<br>• **`B`** = Processado parcialmente *(Faturamento parcial)*<br>• **`C`** = Processado completamente *(Faturamento concluído)* |

### Regras de Expurgos de "Peso Morto" para a Visão de Pendências:
Para garantir que a lista de Backlog reflita apenas pendências operacionais reais e limpe registros sem movimentação futura, remova o registro se:
1. `VBAP-ABGRU` for diferente de vazio (Item cancelado individualmente comercial).
2. `VBAK-LIFSK` for igual a `'Z1'` (Cancelado através de trava física na operação real).
3. `VBAK-VBTYP` for igual a `'B'` (Cotações) ou `'G'` (Contratos).

---

## 3. Visão Focada em Vendas e Faturamento (O Realizado)

Com a **VKORG** e o **AUART** incluídos, consolida-se o faturamento realizado por unidade de negócio e tipo de operação. O join foi reordenado estruturalmente colocando a `VBAK` antes da `VBAP` para ganho substancial de performance no banco do SAP ECC.

### Estrutura do Modelo de Dados (Vendas e Faturamento)

```sql
SELECT
     VBRK.BUKRS   AS [Empresa],
     VBAK.VKORG   AS [Org_Vendas],
     VBAK.AUART   AS [Tipo_Documento],
     VBRK.FKDAT   AS [Data_Faturamento],
     VBRK.VBELN   AS [Nota_Fiscal_SAP],
     VBAK.VBELN   AS [Pedido_Venda],
     VBAK.KUNNR   AS [Codigo_Cliente],
     VBRP.MATNR   AS [Codigo_Produto],
     VBRP.FKIMG   AS [Quantidade_Faturada],
     VBRP.VRKME   AS [Unidade_Medida],
     VBRP.NETWR   AS [Valor_Liquido_Faturado],
     VBAP.KWMENG  AS [Quantidade_Pedida_Original]
FROM VBRK
INNER JOIN VBRP ON VBRK.VBELN = VBRP.VBELN
INNER JOIN VBAK ON VBRP.AUBEL = VBAK.VBELN
INNER JOIN VBAP ON VBAP.VBELN = VBAK.VBELN AND VBAP.POSNR = VBRP.AUPOS
WHERE VBRK.FKSTO = ' ' -- Desconsiderar notas estornadas
  AND VBRK.SFARR = ' ' -- Desconsiderar cancelamentos contábeis adicionais
```

---

## 4. Visão Focada em Pendências (O Backlog / Carteira em Aberto)

Esta visão monitora estritamente o saldo físico em aberto na empresa que possui compromisso real de entrega. Ela utiliza as travas nativas e trata o erro cadastral `Z8` como uma pendência ativa a ser cobrada da equipe de vendas.

### Estrutura do Modelo de Dados (Pendências)

```sql
SELECT
     VBAK.VKORG   AS [Org_Vendas],
     VBAK.AUART   AS [Tipo_Documento],
     VBAK.VBELN   AS [Pedido_Venda],
     VBAK.ERDAT   AS [Data_Criacao_Pedido],
     VBAK.KUNNR   AS [Codigo_Cliente],
     VBAP.POSNR   AS [Item_Pedido],
     VBAP.MATNR   AS [Codigo_Produto],
     VBAP.WERKS   AS [Centro_Expedidor],
     VBAP.KWMENG  AS [Quantidade_Pedida],
     VBUP.LFSTA   AS [Status_Atendimento_Logistico], -- A (Não atendido) ou B (Parcial)
     VBUP.FKSTA   AS [Status_Faturamento],
     -- Inteligência de Causa Raiz baseada na realidade empírica do banco
     CASE 
         WHEN VBUK.CMGST IN ('B', 'C') THEN 'Pendente: Retido por Crédito (Financeiro)'
         WHEN VBAK.LIFSK = '30' THEN 'Pendente: Aguardando Aprovação de Preço'
         WHEN VBAK.LIFSK = 'Z8' THEN 'Pendente: Erro de Cadastro (Cliente Incorreto)'
         WHEN VBUP.LFSTA IN ('A', 'B') THEN 'Pendente: Logística (Falta de Estoque ou Separação)'
         ELSE 'Outros status em aberto'
     END AS [Causa_Raiz_Real]
FROM VBAP
INNER JOIN VBAK ON VBAP.VBELN = VBAK.VBELN
INNER JOIN VBUP ON VBAP.VBELN = VBUP.VBELN AND VBAP.POSNR = VBUP.POSNR
INNER JOIN VBUK ON VBAK.VBELN = VBUK.VBELN -- Acoplado para buscar controle financeiro e global
WHERE VBAP.ABGRU = ' '                   -- Ignora itens cancelados/recusados comercialmente
  AND VBUP.LFSTA IN ('A', 'B')           -- Filtra apenas o que possui pendência física real
  AND VBAK.LIFSK <> 'Z1'                 -- Expuga os cancelados mapeados na realidade da operação (Z1)
  AND VBAK.VBTYP IN ('C', 'I')           -- Restringe a ordens firmes e remessas gratuitas
```
------------------------------------------------------------------------------------------------------

pendencia por BU e por orgnizacao 
grao mes 

faturamento liquido 
canal 
organização vendas
quantidade produto 
* material (dim produto) nome produto
where tipo de ordem (zxp)




